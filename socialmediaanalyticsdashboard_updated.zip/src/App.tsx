import { useState, useEffect } from "react";
import { INITIAL_DATA } from "./data";
import { WeekData, Goals } from "./types";
import {
  BarChart3,
  Instagram,
  Facebook,
  Video,
  LineChart as LineChartIcon,
  Users2,
  SlidersHorizontal,
  Download,
  Upload,
  Eye,
  Heart,
  Clock,
  Bell,
  FileSpreadsheet,
  Keyboard,
  Info,
  X
} from "lucide-react";

import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line
} from "recharts";

import ThemeToggle from "./components/ThemeToggle";
import KPICards from "./components/KPICards";
import PlatformComparison from "./components/PlatformComparison";
import GoalsTracker from "./components/GoalsTracker";
import MockDataGenerator from "./components/MockDataGenerator";
import TrafficSourceChart from "./components/TrafficSourceChart";
import AudienceInsights from "./components/AudienceInsights";
import PerformanceTable from "./components/PerformanceTable";
import ExportModal from "./components/ExportModal";
import GaugeMeter from "./components/GaugeMeter";
import SMMRoiModeler from "./components/SMMRoiModeler";
import AlertsSidebar, { calculateAlerts } from "./components/AlertsSidebar";
import CsvExportModal from "./components/CsvExportModal";
import SpendCorrelationChart from "./components/SpendCorrelationChart";
import ChannelKpiCards from "./components/ChannelKpiCards";

export default function App() {
  // Theme State
  const [darkMode, setDarkMode] = useState<boolean>(true);

  // Core Data States
  const [dataWeeks, setDataWeeks] = useState<WeekData[]>(INITIAL_DATA.weeks);
  const [goals, setGoals] = useState<Goals>(INITIAL_DATA.goals);
  const [audienceData, setAudienceData] = useState(INITIAL_DATA.audience);
  const [lastGenerated, setLastGenerated] = useState<string>(INITIAL_DATA.generated);

  // Active Tab
  const [activeTab, setActiveTab] = useState<"summary" | "ig" | "fb" | "tt" | "ga" | "audience" | "compare">("summary");

  // Filter Preset State ("all" | 4 | 8 | "custom")
  const [presetFilter, setPresetFilter] = useState<"all" | 4 | 8 | "custom">("all");

  // Custom Date Range States
  const [startWeek, setStartWeek] = useState<string>("");
  const [endWeek, setEndWeek] = useState<string>("");

  // Export Modal State
  const [isExportOpen, setIsExportOpen] = useState(false);

  // Alerts Sidebar State
  const [isAlertsOpen, setIsAlertsOpen] = useState(false);

  // Compare Period State
  const [compareMode, setCompareMode] = useState<boolean>(false);

  // CSV Export Modal State
  const [isCsvModalOpen, setIsCsvModalOpen] = useState<boolean>(false);

  // Marketing Budget State
  const [weeklyBudget, setWeeklyBudget] = useState<number>(800);

  // Drag & Drop Uploader Status State
  const [uploadStatus, setUploadStatus] = useState<{ type: "success" | "error" | "idle"; message: string }>({
    type: "idle",
    message: "",
  });

  // Effect to apply dark mode class on HTML document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  // Initial custom date ranges setup based on data weeks
  useEffect(() => {
    if (dataWeeks.length > 0) {
      const sorted = [...dataWeeks].sort((a, b) => a.iso.localeCompare(b.iso));
      setStartWeek(sorted[0].iso);
      setEndWeek(sorted[sorted.length - 1].iso);
    }
  }, [dataWeeks]);

  // Open the customize CSV export modal
  const downloadCSV = () => {
    setIsCsvModalOpen(true);
  };

  // Handle Preset change
  const handlePresetChange = (preset: "all" | 4 | 8) => {
    setPresetFilter(preset);
    if (dataWeeks.length > 0) {
      const sorted = [...dataWeeks].sort((a, b) => a.iso.localeCompare(b.iso));
      setEndWeek(sorted[sorted.length - 1].iso);
      if (preset === "all") {
        setStartWeek(sorted[0].iso);
      } else {
        const startIndex = Math.max(0, sorted.length - preset);
        setStartWeek(sorted[startIndex].iso);
      }
    }
  };

  // Filtered Weeks computation
  const filteredWeeks = [...dataWeeks]
    .sort((a, b) => a.iso.localeCompare(b.iso))
    .filter((w) => {
      return w.iso >= startWeek && w.iso <= endWeek;
    });

  // Calculate trends/previous week benchmarks
  const currentWeek = filteredWeeks[filteredWeeks.length - 1] || dataWeeks[dataWeeks.length - 1];
  const prevWeek = filteredWeeks[filteredWeeks.length - 2] || dataWeeks[dataWeeks.length - 2];

  // Calculate historical benchmark for comparison period
  const sortedAllWeeks = [...dataWeeks].sort((a, b) => a.iso.localeCompare(b.iso));
  const startIdx = sortedAllWeeks.findIndex((w) => w.iso === startWeek);
  const endIdx = sortedAllWeeks.findIndex((w) => w.iso === endWeek);
  const N = (endIdx - startIdx + 1) || 1;
  const comparePrevPeriodWeeks = compareMode
    ? sortedAllWeeks.slice(Math.max(0, startIdx - N), startIdx)
    : [];

  // Append simulated week
  const handleAddWeek = (newWeek: WeekData) => {
    setDataWeeks((prev) => {
      const idx = prev.findIndex((w) => w.iso === newWeek.iso);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = newWeek;
        return copy.sort((a, b) => a.iso.localeCompare(b.iso));
      }
      return [...prev, newWeek].sort((a, b) => a.iso.localeCompare(b.iso));
    });
    setLastGenerated(new Date().toISOString());
    setUploadStatus({
      type: "success",
      message: `Week ${newWeek.iso} simulated successfully!`,
    });
  };

  // Handle drag-and-drop JSON imports
  const handleFileUpload = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];

    if (!file.name.endsWith(".json")) {
      setUploadStatus({ type: "error", message: "Invalid file format. Please upload a .json report." });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const imported = JSON.parse(e.target?.result as string);
        if (imported.weeks && Array.isArray(imported.weeks)) {
          setDataWeeks((prev) => {
            const merged = [...prev];
            imported.weeks.forEach((nw: WeekData) => {
              const matchIdx = merged.findIndex((w) => w.iso === nw.iso);
              if (matchIdx >= 0) {
                merged[matchIdx] = nw;
              } else {
                merged.push(nw);
              }
            });
            return merged.sort((a, b) => a.iso.localeCompare(b.iso));
          });

          if (imported.audience) {
            setAudienceData(imported.audience);
          }
          if (imported.goals) {
            setGoals(imported.goals);
          }

          setLastGenerated(new Date().toISOString());
          setUploadStatus({
            type: "success",
            message: `Successfully imported ${imported.weeks.length} performance log weeks!`,
          });
        } else {
          setUploadStatus({ type: "error", message: "Import failed: Missing a valid 'weeks' array." });
        }
      } catch (err) {
        setUploadStatus({ type: "error", message: "Failed to decode the JSON file." });
      }
    };
    reader.readAsText(file);
  };

  // Format Helper utils
  const formatNum = (num: number) => Math.round(num).toLocaleString();
  const formatCurrency = (num: number) => `$${Math.round(num).toLocaleString()}`;

  // Custom tooltips for recharts
  const CustomRechartTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg shadow-xl font-sans text-xs">
          <p className="font-bold text-slate-300">{label}</p>
          {payload.map((item: any, i: number) => (
            <p key={i} style={{ color: item.color }} className="mt-1 font-semibold">
              {item.name}: {typeof item.value === "number" && item.name.includes("Revenue") ? formatCurrency(item.value) : formatNum(item.value)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div
      id="main-dashboard-app"
      className="min-h-screen font-sans antialiased transition-colors duration-300
        dark:bg-slate-950 dark:text-slate-100 bg-slate-50 text-slate-800"
    >
      {/* Top Banner Navigation */}
      <header className="no-print sticky top-0 z-40 w-full border-b backdrop-blur-md dark:bg-slate-950/80 dark:border-slate-900 bg-white/80 border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-md">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-extrabold tracking-tight dark:text-slate-100 text-slate-900">
                Alaska Wild Lights
              </h1>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                Social Performance Hub
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Dark Mode toggle */}
            <ThemeToggle darkMode={darkMode} setDarkMode={setDarkMode} />

            {/* Import JSON Button */}
            <button
              onClick={() => document.getElementById("header-file-picker")?.click()}
              className="py-2 px-2.5 sm:px-3 rounded-xl border font-bold text-xs flex items-center gap-1.5 transition-all duration-200 cursor-pointer
                dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800
                border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:shadow"
              title="Import JSON weekly report files"
              aria-label="Import JSON weekly report files"
            >
              <Upload className="w-4 h-4 text-indigo-500" />
              <span className="hidden sm:inline">Import JSON</span>
            </button>
            <input
              id="header-file-picker"
              type="file"
              accept=".json"
              className="hidden"
              onChange={(e) => handleFileUpload(e.target.files)}
            />

            {/* Download CSV Button */}
            <button
              onClick={downloadCSV}
              className="py-2 px-2.5 sm:px-3 rounded-xl border font-bold text-xs flex items-center gap-1.5 transition-all duration-200 cursor-pointer
                dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800
                border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:shadow"
              title="Download raw data in CSV format"
              aria-label="Download raw data in CSV format"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-500" />
              <span className="hidden sm:inline">Download CSV</span>
            </button>

            {/* Export PDF Button */}
            <button
              onClick={() => setIsExportOpen(true)}
              className="py-2 px-2.5 sm:px-3 rounded-xl border font-bold text-xs flex items-center gap-1.5 transition-all duration-200 cursor-pointer
                dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800
                border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:shadow"
              title="Export print-ready PDF document"
              aria-label="Export print-ready PDF document"
            >
              <Download className="w-4 h-4 text-indigo-500" />
              <span className="hidden sm:inline">Export PDF</span>
            </button>

            {/* Alerts Bell Button */}
            {(() => {
              const activeAlertsCount = calculateAlerts(dataWeeks).length;
              return (
                <button
                  onClick={() => setIsAlertsOpen(true)}
                  className="relative p-2 rounded-xl border flex items-center justify-center transition-all duration-200 cursor-pointer
                    dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800
                    border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:shadow"
                  title="View Performance Alerts & Spikes (Alt + A)"
                  aria-label={`View Performance Alerts & Spikes. ${activeAlertsCount} active alerts.`}
                >
                  <Bell className="w-4.5 h-4.5 text-indigo-500" />
                  {activeAlertsCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-4.5 h-4.5 bg-rose-500 text-white font-extrabold text-[9px] rounded-full flex items-center justify-center animate-pulse">
                      {activeAlertsCount}
                    </span>
                  )}
                </button>
              );
            })()}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Date Range Selector & Global Filter Controls */}
        <div className="no-print mb-6 p-4 rounded-2xl border dark:bg-slate-900 dark:border-slate-900 bg-white border-slate-200 flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-center gap-3 self-start md:self-auto">
            <SlidersHorizontal className="w-4.5 h-4.5 text-indigo-500" />
            <div>
              <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300">Report Filter Range</h3>
              <p className="text-[10px] text-slate-400 font-medium">Personalize the analyzed chronological data window.</p>
            </div>
          </div>

          {/* Presets and Custom Week selectors */}
          <div className="flex flex-wrap items-center gap-3 self-start md:self-auto w-full md:w-auto">
            <div className="flex rounded-xl bg-slate-100 dark:bg-slate-950 p-1 border dark:border-slate-800 border-slate-200">
              <button
                onClick={() => handlePresetChange("all")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer ${
                  presetFilter === "all"
                    ? "bg-white dark:bg-slate-900 text-indigo-500 dark:text-indigo-400 shadow"
                    : "text-slate-400 hover:text-slate-600"
                }`}
              >
                All Time
              </button>
              <button
                onClick={() => handlePresetChange(4)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer ${
                  presetFilter === 4
                    ? "bg-white dark:bg-slate-900 text-indigo-500 dark:text-indigo-400 shadow"
                    : "text-slate-400 hover:text-slate-600"
                }`}
              >
                Last 4 Weeks
              </button>
              <button
                onClick={() => handlePresetChange(8)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer ${
                  presetFilter === 8
                    ? "bg-white dark:bg-slate-900 text-indigo-500 dark:text-indigo-400 shadow"
                    : "text-slate-400 hover:text-slate-600"
                }`}
              >
                Last 8 Weeks
              </button>
              <button
                onClick={() => setPresetFilter("custom")}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer ${
                  presetFilter === "custom"
                    ? "bg-white dark:bg-slate-900 text-indigo-500 dark:text-indigo-400 shadow"
                    : "text-slate-400 hover:text-slate-600"
                }`}
              >
                Custom Range
              </button>
            </div>

            {/* Start and End dropdown range */}
            {presetFilter === "custom" && (
              <div className="flex items-center gap-2 animate-fade-in-up">
                <select
                  value={startWeek}
                  onChange={(e) => setStartWeek(e.target.value)}
                  aria-label="Start report week"
                  className="px-2.5 py-1.5 rounded-lg text-xs font-semibold border dark:bg-slate-950 dark:border-slate-800 dark:text-slate-200 border-slate-200 text-slate-700 outline-none cursor-pointer focus:ring-2 focus:ring-indigo-500"
                >
                  {[...dataWeeks]
                    .sort((a, b) => a.iso.localeCompare(b.iso))
                    .map((w) => (
                      <option key={w.iso} value={w.iso}>
                        {w.iso}
                      </option>
                    ))}
                </select>
                <span className="text-xs text-slate-400 font-semibold" aria-hidden="true">to</span>
                <select
                  value={endWeek}
                  onChange={(e) => setEndWeek(e.target.value)}
                  aria-label="End report week"
                  className="px-2.5 py-1.5 rounded-lg text-xs font-semibold border dark:bg-slate-950 dark:border-slate-800 dark:text-slate-200 border-slate-200 text-slate-700 outline-none cursor-pointer focus:ring-2 focus:ring-indigo-500"
                >
                  {[...dataWeeks]
                    .sort((a, b) => a.iso.localeCompare(b.iso))
                    .filter((w) => w.iso >= startWeek)
                    .map((w) => (
                      <option key={w.iso} value={w.iso}>
                        {w.iso}
                      </option>
                    ))}
                </select>
              </div>
            )}

            {/* Compare Period Toggle */}
            <div className="flex items-center gap-2 border-l border-slate-200 dark:border-slate-800 pl-3 h-6">
              <label className="relative inline-flex items-center cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={compareMode}
                  onChange={(e) => setCompareMode(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-8 h-4.5 bg-slate-200 dark:bg-slate-800 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-indigo-600"></div>
                <span className="ml-2 text-xs font-bold text-slate-700 dark:text-slate-300 whitespace-nowrap">Compare Period</span>
              </label>
            </div>
          </div>
        </div>

        {/* Global tab selection */}
        <div className="no-print flex border-b dark:border-slate-900 border-slate-200 mb-6 overflow-x-auto gap-4 scrollbar-thin">
          {[
            { id: "summary", label: "Executive Overview", icon: BarChart3 },
            { id: "ig", label: "Instagram Channel", icon: Instagram },
            { id: "fb", label: "Facebook Channel", icon: Facebook },
            { id: "tt", label: "TikTok Channel", icon: Video },
            { id: "ga", label: "Google Analytics", icon: LineChartIcon },
            { id: "audience", label: "Audience Demographics", icon: Users2 },
            { id: "compare", label: "Platform Head-to-Head", icon: SlidersHorizontal },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`pb-3 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-all cursor-pointer whitespace-nowrap px-1 ${
                  active
                    ? "border-indigo-600 text-indigo-600 dark:border-indigo-400 dark:text-indigo-400"
                    : "border-transparent text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Target container for exporting reports to PDF */}
        <div id="capture-report-container" className="space-y-6">
          {/* Active filter summary (Included in print views) */}
          <div className="hidden print:flex justify-between items-center border-b pb-4 mb-4">
            <div>
              <h2 className="text-xl font-extrabold text-slate-900">Alaska Wild Lights Performance Hub</h2>
              <p className="text-xs text-slate-500 mt-1">
                Report Period: {startWeek} ({filteredWeeks[0]?.label}) to {endWeek} ({currentWeek?.label})
              </p>
            </div>
            <span className="text-xs font-bold font-mono text-indigo-600">Generated on: {new Date().toLocaleDateString()}</span>
          </div>

          {/* Render KPI Summary cards across tabs */}
          {activeTab !== "compare" && activeTab !== "audience" && (
            <KPICards
              currentWeek={currentWeek}
              prevWeek={prevWeek}
              weeks={filteredWeeks}
              compareMode={compareMode}
              comparePrevPeriodWeeks={comparePrevPeriodWeeks}
            />
          )}

          {/* TAB 1: SUMMARY / GENERAL DASHBOARD */}
          {activeTab === "summary" && (
            <div className="space-y-6">
              {/* Dynamic Goal Progress Strip */}
              <GoalsTracker currentWeek={currentWeek} initialGoals={goals} />

              {/* SMM Target Dial Gauge Meters */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <GaugeMeter
                  value={currentWeek.ig_followers}
                  target={goals.ig_followers}
                  title="Instagram Followers Target"
                  color="#ec4899"
                />
                <GaugeMeter
                  value={currentWeek.ig_eng * 100}
                  target={goals.ig_eng_rate}
                  title="IG Engagement Rate Target"
                  unit="%"
                  color="#6366f1"
                />
                <GaugeMeter
                  value={currentWeek.tt_followers}
                  target={goals.tt_followers}
                  title="TikTok Followers Target"
                  color="#14b8a6"
                />
              </div>

              {/* Main Graphs Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Followers comparative */}
                <div className="p-5 rounded-2xl border dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-4">
                    Cumulative Social Community Evolution
                  </h4>
                  <div
                    className="h-64"
                    role="region"
                    aria-label="Cumulative Social Community Evolution Chart"
                    aria-describedby="community-evolution-desc"
                  >
                    <div id="community-evolution-desc" className="sr-only">
                      {filteredWeeks.length > 0
                        ? `Cumulative Social Community Evolution chart tracking weekly follower trends for Instagram and TikTok. Currently displaying ${filteredWeeks.length} weeks. Instagram followers started at ${filteredWeeks[0]?.ig_followers?.toLocaleString()} and grew to ${filteredWeeks[filteredWeeks.length - 1]?.ig_followers?.toLocaleString()}. TikTok followers started at ${filteredWeeks[0]?.tt_followers?.toLocaleString()} and grew to ${filteredWeeks[filteredWeeks.length - 1]?.tt_followers?.toLocaleString()}.`
                        : "Cumulative Social Community Evolution chart. No data is currently filtered."}
                    </div>
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={filteredWeeks} accessibilityLayer>
                        <defs>
                          <linearGradient id="colorIg" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#ec4899" stopOpacity={0.2} />
                            <stop offset="95%" stopColor="#ec4899" stopOpacity={0.02} />
                          </linearGradient>
                          <linearGradient id="colorTt" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.2} />
                            <stop offset="95%" stopColor="#14b8a6" stopOpacity={0.02} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="iso" stroke="#94a3b8" fontSize={9} interval={0} angle={-30} textAnchor="end" height={45} />
                        <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                        <Tooltip content={<CustomRechartTooltip />} />
                        <Legend iconType="circle" />
                        <Area
                          type="monotone"
                          name="Instagram Followers"
                          dataKey="ig_followers"
                          stroke="#ec4899"
                          strokeWidth={2.5}
                          fillOpacity={1}
                          fill="url(#colorIg)"
                        />
                        <Area
                          type="monotone"
                          name="TikTok Followers"
                          dataKey="tt_followers"
                          stroke="#14b8a6"
                          strokeWidth={2.5}
                          fillOpacity={1}
                          fill="url(#colorTt)"
                        />
                        {/* High-fidelity dots and value overlays so it works as an accurate meter */}
                        <Line
                          type="monotone"
                          dataKey="ig_followers"
                          stroke="transparent"
                          dot={{ r: 4, fill: "#ec4899" }}
                          label={{ fill: "#64748b", fontSize: 9, position: "top", offset: 10 }}
                          legendType="none"
                        />
                        <Line
                          type="monotone"
                          dataKey="tt_followers"
                          stroke="transparent"
                          dot={{ r: 4, fill: "#14b8a6" }}
                          label={{ fill: "#64748b", fontSize: 9, position: "top", offset: 10 }}
                          legendType="none"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Video views comparison */}
                <div className="p-5 rounded-2xl border dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-4">
                    Cumulative Core Video Views by Platform
                  </h4>
                  <div
                    className="h-64"
                    role="region"
                    aria-label="Cumulative Core Video Views by Platform Chart"
                    aria-describedby="video-views-desc"
                  >
                    <div id="video-views-desc" className="sr-only">
                      {filteredWeeks.length > 0
                        ? `Bar chart comparing total video views across Instagram, Facebook, and TikTok. For the latest week, Instagram video views are ${filteredWeeks[filteredWeeks.length - 1]?.ig_views?.toLocaleString()}, Facebook views are ${filteredWeeks[filteredWeeks.length - 1]?.fb_views?.toLocaleString()}, and TikTok views are ${filteredWeeks[filteredWeeks.length - 1]?.tt_views?.toLocaleString()}.`
                        : "Video views comparison chart. No data is currently filtered."}
                    </div>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={filteredWeeks} accessibilityLayer>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="iso" stroke="#94a3b8" fontSize={9} interval={0} angle={-30} textAnchor="end" height={45} />
                        <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                        <Tooltip content={<CustomRechartTooltip />} />
                        <Legend iconType="rect" />
                        <Bar name="Instagram Views" dataKey="ig_views" fill="#ec4899" radius={[3, 3, 0, 0]} label={{ fill: '#64748b', fontSize: 8, position: 'top' }} />
                        <Bar name="Facebook Views" dataKey="fb_views" fill="#3b82f6" radius={[3, 3, 0, 0]} label={{ fill: '#64748b', fontSize: 8, position: 'top' }} />
                        <Bar name="TikTok Views" dataKey="tt_views" fill="#14b8a6" radius={[3, 3, 0, 0]} label={{ fill: '#64748b', fontSize: 8, position: 'top' }} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Ad Spend & Follower Growth Correlation Chart */}
              <SpendCorrelationChart filteredWeeks={filteredWeeks} weeklyBudget={weeklyBudget} />

              {/* Paid Campaign ROI Modeler Panel */}
              <SMMRoiModeler
                filteredWeeks={filteredWeeks}
                weeklyBudget={weeklyBudget}
                setWeeklyBudget={setWeeklyBudget}
              />

              {/* Historic Table */}
              <PerformanceTable weeks={filteredWeeks} />
            </div>
          )}

          {/* TAB 2: INSTAGRAM */}
          {activeTab === "ig" && (
            <div className="space-y-6">
              {/* Specialized Instagram Channel KPI Summary */}
              <ChannelKpiCards
                channel="ig"
                filteredWeeks={filteredWeeks}
                compareWeeks={comparePrevPeriodWeeks}
                compareMode={compareMode}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Reach Area chart */}
                <div className="p-5 rounded-2xl border dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 border-l-4 border-l-pink-500 dark:border-l-pink-400">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-4">
                    Instagram Accounts Reached Trend
                  </h4>
                  <div
                    className="h-64"
                    role="region"
                    aria-label="Instagram Accounts Reached Trend Chart"
                    aria-describedby="ig-reach-chart-desc"
                  >
                    <div id="ig-reach-chart-desc" className="sr-only">
                      {filteredWeeks.length > 0
                        ? `Area chart displaying the trend of Instagram accounts reached weekly. In the latest week, the reach is ${filteredWeeks[filteredWeeks.length - 1]?.ig_reach?.toLocaleString()}.`
                        : "Instagram Accounts Reached Trend Chart. No data is currently filtered."}
                    </div>
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={filteredWeeks} accessibilityLayer>
                        <defs>
                          <linearGradient id="colorReach" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#ec4899" stopOpacity={0.2} />
                            <stop offset="95%" stopColor="#ec4899" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="iso" stroke="#94a3b8" fontSize={9} interval={0} angle={-30} textAnchor="end" height={45} />
                        <YAxis stroke="#94a3b8" fontSize={10} />
                        <Tooltip content={<CustomRechartTooltip />} />
                        <Area type="monotone" name="Reach" dataKey="ig_reach" stroke="#ec4899" strokeWidth={2.5} fillOpacity={1} fill="url(#colorReach)" />
                        <Line type="monotone" dataKey="ig_reach" stroke="transparent" dot={{ r: 4, fill: "#ec4899" }} label={{ fill: '#64748b', fontSize: 9, position: 'top', offset: 10 }} legendType="none" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Interactions metric graph */}
                <div className="p-5 rounded-2xl border dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 border-l-4 border-l-pink-500 dark:border-l-pink-400">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-4">
                    Instagram Total Weekly Engagement Actions
                  </h4>
                  <div
                    className="h-64"
                    role="region"
                    aria-label="Instagram Total Weekly Engagement Actions Chart"
                    aria-describedby="ig-inter-chart-desc"
                  >
                    <div id="ig-inter-chart-desc" className="sr-only">
                      {filteredWeeks.length > 0
                        ? `Bar chart showing Instagram total weekly engagement actions. For the latest week, total engagements are ${filteredWeeks[filteredWeeks.length - 1]?.ig_inter?.toLocaleString()}.`
                        : "Instagram Total Weekly Engagement Actions Chart. No data is currently filtered."}
                    </div>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={filteredWeeks} accessibilityLayer>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="iso" stroke="#94a3b8" fontSize={9} interval={0} angle={-30} textAnchor="end" height={45} />
                        <YAxis stroke="#94a3b8" fontSize={10} />
                        <Tooltip content={<CustomRechartTooltip />} />
                        <Bar name="Interactions" dataKey="ig_inter" fill="#f43f5e" radius={[3, 3, 0, 0]} label={{ fill: '#64748b', fontSize: 9, position: 'top' }} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Engagement Rate Analysis */}
              <div className="p-5 rounded-2xl border dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 border-l-4 border-l-pink-500 dark:border-l-pink-400">
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-4">
                  Instagram Engagement Rate Trend (Engagement / Followers Ratio)
                </h4>
                <div
                  className="h-64"
                  role="region"
                  aria-label="Instagram Engagement Rate Trend Chart"
                  aria-describedby="ig-eng-chart-desc"
                >
                  <div id="ig-eng-chart-desc" className="sr-only">
                    {filteredWeeks.length > 0
                      ? `Line chart exhibiting Instagram engagement rate trends over time. The latest engagement rate is ${(filteredWeeks[filteredWeeks.length - 1]?.ig_eng * 100).toFixed(2)}%.`
                      : "Instagram Engagement Rate Trend Chart. No data is currently filtered."}
                  </div>
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={filteredWeeks} accessibilityLayer>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                      <XAxis dataKey="iso" stroke="#94a3b8" fontSize={9} interval={0} angle={-30} textAnchor="end" height={45} />
                      <YAxis stroke="#94a3b8" fontSize={10} tickFormatter={(v) => `${(v * 100).toFixed(0)}%`} />
                      <Tooltip formatter={(value: any) => `${(parseFloat(value) * 100).toFixed(2)}%`} />
                      <Line type="monotone" name="Engagement Rate" dataKey="ig_eng" stroke="#ec4899" strokeWidth={3} dot={{ r: 5 }} label={{ fill: '#64748b', fontSize: 9, position: 'top', offset: 12, formatter: (v: any) => `${(v * 100).toFixed(1)}%` }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: FACEBOOK */}
          {activeTab === "fb" && (
            <div className="space-y-6">
              {/* Specialized Facebook Channel KPI Summary */}
              <ChannelKpiCards
                channel="fb"
                filteredWeeks={filteredWeeks}
                compareWeeks={comparePrevPeriodWeeks}
                compareMode={compareMode}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-5 rounded-2xl border dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 border-l-4 border-l-blue-500 dark:border-l-blue-400">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-4">
                    Facebook Channel Cumulative Impressions
                  </h4>
                  <div
                    className="h-64"
                    role="region"
                    aria-label="Facebook Channel Cumulative Impressions Chart"
                    aria-describedby="fb-views-chart-desc"
                  >
                    <div id="fb-views-chart-desc" className="sr-only">
                      {filteredWeeks.length > 0
                        ? `Area chart measuring cumulative weekly Facebook views. Latest weekly views recorded at ${filteredWeeks[filteredWeeks.length - 1]?.fb_views?.toLocaleString()}.`
                        : "Facebook Channel Cumulative Impressions Chart. No data is currently filtered."}
                    </div>
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={filteredWeeks} accessibilityLayer>
                        <defs>
                          <linearGradient id="colorFbViews" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2} />
                            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="iso" stroke="#94a3b8" fontSize={9} interval={0} angle={-30} textAnchor="end" height={45} />
                        <YAxis stroke="#94a3b8" fontSize={10} />
                        <Tooltip content={<CustomRechartTooltip />} />
                        <Area type="monotone" name="Views" dataKey="fb_views" stroke="#3b82f6" strokeWidth={2.5} fillOpacity={1} fill="url(#colorFbViews)" />
                        <Line type="monotone" dataKey="fb_views" stroke="transparent" dot={{ r: 4, fill: "#3b82f6" }} label={{ fill: '#64748b', fontSize: 9, position: 'top', offset: 10 }} legendType="none" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="p-5 rounded-2xl border dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 border-l-4 border-l-blue-500 dark:border-l-blue-400">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-4">
                    Facebook Page Post Engagements
                  </h4>
                  <div
                    className="h-64"
                    role="region"
                    aria-label="Facebook Page Post Engagements Chart"
                    aria-describedby="fb-inter-chart-desc"
                  >
                    <div id="fb-inter-chart-desc" className="sr-only">
                      {filteredWeeks.length > 0
                        ? `Bar chart of weekly Facebook page engagements. The latest weekly engagements are ${filteredWeeks[filteredWeeks.length - 1]?.fb_inter?.toLocaleString()}.`
                        : "Facebook Page Post Engagements Chart. No data is currently filtered."}
                    </div>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={filteredWeeks} accessibilityLayer>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="iso" stroke="#94a3b8" fontSize={9} interval={0} angle={-30} textAnchor="end" height={45} />
                        <YAxis stroke="#94a3b8" fontSize={10} />
                        <Tooltip content={<CustomRechartTooltip />} />
                        <Bar name="Interactions" dataKey="fb_inter" fill="#2563eb" radius={[3, 3, 0, 0]} label={{ fill: '#64748b', fontSize: 9, position: 'top' }} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: TIKTOK */}
          {activeTab === "tt" && (
            <div className="space-y-6">
              {/* Specialized TikTok Channel KPI Summary */}
              <ChannelKpiCards
                channel="tt"
                filteredWeeks={filteredWeeks}
                compareWeeks={comparePrevPeriodWeeks}
                compareMode={compareMode}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-5 rounded-2xl border dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 border-l-4 border-l-teal-500 dark:border-l-teal-400">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-4">
                    TikTok Weekly Views Performance
                  </h4>
                  <div
                    className="h-64"
                    role="region"
                    aria-label="TikTok Weekly Views Performance Chart"
                    aria-describedby="tt-views-chart-desc"
                  >
                    <div id="tt-views-chart-desc" className="sr-only">
                      {filteredWeeks.length > 0
                        ? `Area chart depicting weekly TikTok video views. In the latest week, the view count is ${filteredWeeks[filteredWeeks.length - 1]?.tt_views?.toLocaleString()}.`
                        : "TikTok Weekly Views Performance Chart. No data is currently filtered."}
                    </div>
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={filteredWeeks} accessibilityLayer>
                        <defs>
                          <linearGradient id="colorTtViews" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.2} />
                            <stop offset="95%" stopColor="#14b8a6" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="iso" stroke="#94a3b8" fontSize={9} interval={0} angle={-30} textAnchor="end" height={45} />
                        <YAxis stroke="#94a3b8" fontSize={10} />
                        <Tooltip content={<CustomRechartTooltip />} />
                        <Area type="monotone" name="Video Views" dataKey="tt_views" stroke="#14b8a6" strokeWidth={2.5} fillOpacity={1} fill="url(#colorTtViews)" />
                        <Line type="monotone" dataKey="tt_views" stroke="transparent" dot={{ r: 4, fill: "#14b8a6" }} label={{ fill: '#64748b', fontSize: 9, position: 'top', offset: 10 }} legendType="none" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="p-5 rounded-2xl border dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 border-l-4 border-l-teal-500 dark:border-l-teal-400">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-4">
                    TikTok Weekly Video Likes
                  </h4>
                  <div
                    className="h-64"
                    role="region"
                    aria-label="TikTok Weekly Video Likes Chart"
                    aria-describedby="tt-likes-chart-desc"
                  >
                    <div id="tt-likes-chart-desc" className="sr-only">
                      {filteredWeeks.length > 0
                        ? `Bar chart highlighting weekly TikTok video likes. For the latest week, total video likes are ${filteredWeeks[filteredWeeks.length - 1]?.tt_likes?.toLocaleString()}.`
                        : "TikTok Weekly Video Likes Chart. No data is currently filtered."}
                    </div>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={filteredWeeks} accessibilityLayer>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="iso" stroke="#94a3b8" fontSize={9} interval={0} angle={-30} textAnchor="end" height={45} />
                        <YAxis stroke="#94a3b8" fontSize={10} />
                        <Tooltip content={<CustomRechartTooltip />} />
                        <Bar name="Likes" dataKey="tt_likes" fill="#0d9488" radius={[3, 3, 0, 0]} label={{ fill: '#64748b', fontSize: 9, position: 'top' }} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Top performing videos section */}
              {currentWeek.tt_top_videos && currentWeek.tt_top_videos.length > 0 && (
                <div className="p-5 rounded-2xl border dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 border-l-4 border-l-teal-500 dark:border-l-teal-400">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-1.5">
                    <Video className="w-5 h-5 text-indigo-500" />
                    Top Performing TikTok Videos of the Week
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {currentWeek.tt_top_videos.map((vid, idx) => (
                      <div
                        key={idx}
                        className="p-4 rounded-xl border dark:border-slate-800 border-slate-100 dark:bg-slate-950 bg-slate-50 flex flex-col justify-between transition-all duration-300 hover:shadow-md hover:border-slate-200 dark:hover:border-slate-700"
                      >
                        <div>
                          <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 line-clamp-3 leading-relaxed mb-3">
                            "{vid.title || "Untitled Video"}"
                          </p>
                        </div>
                        <div className="flex justify-between items-center text-[11px] text-slate-400 font-mono border-t pt-3 dark:border-slate-800 border-slate-200">
                          <span className="flex items-center gap-1">
                            <Eye className="w-3.5 h-3.5 text-teal-500" />
                            {formatNum(vid.views)}
                          </span>
                          <span className="flex items-center gap-1">
                            <Heart className="w-3.5 h-3.5 text-rose-500" />
                            {formatNum(vid.likes)}
                          </span>
                          {vid.link && (
                            <a
                              href={vid.link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-2 py-1 rounded bg-indigo-500 hover:bg-indigo-600 text-white font-sans font-semibold text-[10px]"
                            >
                              View
                            </a>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: GOOGLE ANALYTICS */}
          {activeTab === "ga" && (
            <div className="space-y-6">
              {/* Specialized Google Analytics Channel KPI Summary */}
              <ChannelKpiCards
                channel="ga"
                filteredWeeks={filteredWeeks}
                compareWeeks={comparePrevPeriodWeeks}
                compareMode={compareMode}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-5 rounded-2xl border dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 border-l-4 border-l-emerald-500 dark:border-l-emerald-400">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-4">
                    Google Analytics Inbound Traffic Sessions
                  </h4>
                  <div
                    className="h-64"
                    role="region"
                    aria-label="Google Analytics Inbound Traffic Sessions Chart"
                    aria-describedby="ga-sessions-chart-desc"
                  >
                    <div id="ga-sessions-chart-desc" className="sr-only">
                      {filteredWeeks.length > 0
                        ? `Area chart measuring weekly inbound GA traffic sessions. In the latest week, total sessions reached ${filteredWeeks[filteredWeeks.length - 1]?.ga_sessions?.toLocaleString()}.`
                        : "Google Analytics Inbound Traffic Sessions Chart. No data is currently filtered."}
                    </div>
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={filteredWeeks} accessibilityLayer>
                        <defs>
                          <linearGradient id="colorGaSessions" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10b981" stopOpacity={0.2} />
                            <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="iso" stroke="#94a3b8" fontSize={9} interval={0} angle={-30} textAnchor="end" height={45} />
                        <YAxis stroke="#94a3b8" fontSize={10} />
                        <Tooltip content={<CustomRechartTooltip />} />
                        <Area type="monotone" name="Traffic Sessions" dataKey="ga_sessions" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorGaSessions)" />
                        <Line type="monotone" dataKey="ga_sessions" stroke="transparent" dot={{ r: 4, fill: "#10b981" }} label={{ fill: '#64748b', fontSize: 9, position: 'top', offset: 10 }} legendType="none" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="p-5 rounded-2xl border dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 border-l-4 border-l-emerald-500 dark:border-l-emerald-400">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mb-4">
                    Ecommerce Conversion Sales Revenue (USD)
                  </h4>
                  <div
                    className="h-64"
                    role="region"
                    aria-label="Ecommerce Conversion Sales Revenue (USD) Chart"
                    aria-describedby="ga-revenue-chart-desc"
                  >
                    <div id="ga-revenue-chart-desc" className="sr-only">
                      {filteredWeeks.length > 0
                        ? `Bar chart of weekly GA ecommerce conversion sales revenue. For the latest week, total revenue is $${Math.round(filteredWeeks[filteredWeeks.length - 1]?.ga_revenue)?.toLocaleString()}.`
                        : "Ecommerce Conversion Sales Revenue Chart. No data is currently filtered."}
                    </div>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={filteredWeeks} accessibilityLayer>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.04)" />
                        <XAxis dataKey="iso" stroke="#94a3b8" fontSize={9} interval={0} angle={-30} textAnchor="end" height={45} />
                        <YAxis stroke="#94a3b8" fontSize={10} />
                        <Tooltip content={<CustomRechartTooltip />} />
                        <Bar name="Revenue ($)" dataKey="ga_revenue" fill="#059669" radius={[3, 3, 0, 0]} label={{ fill: '#64748b', fontSize: 8, position: 'top', formatter: (v: any) => `$${Math.round(v)}` }} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Traffic sources pie breakdown */}
              {currentWeek.ga_sources && currentWeek.ga_sources.length > 0 && (
                <TrafficSourceChart sources={currentWeek.ga_sources} />
              )}
            </div>
          )}

          {/* TAB 6: AUDIENCE DEMOGRAPHICS */}
          {activeTab === "audience" && audienceData && (
            <AudienceInsights audience={audienceData} />
          )}

          {/* TAB 7: platform head to head */}
          {activeTab === "compare" && (
            <PlatformComparison currentWeek={currentWeek} />
          )}
        </div>

        {/* Simulador and Uploader Controls (No-Print view) */}
        <div className="no-print mt-12 grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Week Generator mock tool */}
          <MockDataGenerator weeks={dataWeeks} onAddWeek={handleAddWeek} />

          {/* Drag and Drop Report Importer */}
          <div
            id="drag-and-drop-importer"
            className="p-6 rounded-2xl border transition-all duration-300 bg-white border-slate-200 dark:bg-slate-900 dark:border-slate-900 hover:shadow-md"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 bg-indigo-100 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-xl">
                <Upload className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                  Import & Merge JSON Performance Reports
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Drop weekly report datasets generated by Apps Script to consolidate them.
                </p>
              </div>
            </div>

            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                handleFileUpload(e.dataTransfer.files);
              }}
              className="border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition dark:border-slate-800 border-slate-200 dark:hover:border-indigo-500 hover:border-indigo-500"
              onClick={() => document.getElementById("file-picker")?.click()}
            >
              <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                Drag and drop your report .json file here, or click to browse
              </p>
              <p className="text-[10px] text-slate-400 mt-1">Supports raw individual weekly reports or collective multi-week datasets.</p>
              <input
                id="file-picker"
                type="file"
                accept=".json"
                className="hidden"
                onChange={(e) => handleFileUpload(e.target.files)}
              />
            </div>

            {/* Upload status message */}
            {uploadStatus.type !== "idle" && (
              <div
                className={`mt-4 p-3 rounded-xl border text-xs flex items-center gap-2 ${
                  uploadStatus.type === "success"
                    ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500 font-semibold"
                    : "bg-rose-500/10 border-rose-500/20 text-rose-500 font-semibold"
                }`}
              >
                <span>{uploadStatus.message}</span>
                <button
                  onClick={() => setUploadStatus({ type: "idle", message: "" })}
                  className="ml-auto text-[10px] font-bold text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  Close
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Footer info banner */}
        <footer className="no-print mt-12 py-6 border-t dark:border-slate-900 border-slate-200 text-center text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>&copy; 2026 Alaska Wild Lights. All rights reserved.</p>
          <div className="flex items-center gap-1.5 font-mono text-[10px] text-slate-500 bg-slate-100 dark:bg-slate-950 px-2.5 py-1 rounded-full border dark:border-slate-800 border-slate-200">
            <Clock className="w-3.5 h-3.5 animate-pulse text-indigo-500" />
            <span>Last Console Update: {new Date(lastGenerated).toLocaleString()}</span>
          </div>
        </footer>
      </main>

      {/* Export Report to PDF Modal dialog */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        targetRefId="capture-report-container"
      />

      {/* Alerts & Anomalies Sidebar */}
      <AlertsSidebar
        isOpen={isAlertsOpen}
        onClose={() => setIsAlertsOpen(false)}
        weeks={dataWeeks}
        onSelectPlatformTab={(tab) => setActiveTab(tab)}
      />

      {/* Customizable CSV Export Modal */}
      <CsvExportModal
        isOpen={isCsvModalOpen}
        onClose={() => setIsCsvModalOpen(false)}
        filteredWeeks={filteredWeeks}
        startWeek={startWeek}
        endWeek={endWeek}
      />
    </div>
  );
}
