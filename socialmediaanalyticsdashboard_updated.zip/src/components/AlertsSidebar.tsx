import { useState, useEffect, useRef } from "react";
import { WeekData } from "../types";
import {
  X,
  AlertCircle,
  TrendingUp,
  TrendingDown,
  Search,
  SlidersHorizontal,
  Bell,
  Instagram,
  Facebook,
  Video,
  LineChart as LineChartIcon,
  HelpCircle
} from "lucide-react";

export interface AlertItem {
  weekIso: string;
  weekLabel: string;
  metricName: string;
  metricKey: string;
  currentValue: number;
  movingAvgValue: number;
  deviation: number;
  type: "spike" | "drop";
  platform: "Instagram" | "Facebook" | "TikTok" | "Google Analytics";
}

// Trailing moving average calculator
export function calculateAlerts(weeks: WeekData[]): AlertItem[] {
  const sortedWeeks = [...weeks].sort((a, b) => a.iso.localeCompare(b.iso));
  const alerts: AlertItem[] = [];

  const metrics: {
    key: keyof WeekData;
    name: string;
    platform: "Instagram" | "Facebook" | "TikTok" | "Google Analytics";
  }[] = [
    { key: "ig_reach", name: "Instagram Reach", platform: "Instagram" },
    { key: "ig_views", name: "Instagram Views", platform: "Instagram" },
    { key: "ig_inter", name: "Instagram Engagements", platform: "Instagram" },
    { key: "fb_views", name: "Facebook Impressions", platform: "Facebook" },
    { key: "fb_inter", name: "Facebook Post Engagements", platform: "Facebook" },
    { key: "tt_views", name: "TikTok Video Views", platform: "TikTok" },
    { key: "tt_likes", name: "TikTok Video Likes", platform: "TikTok" },
    { key: "ga_sessions", name: "GA Traffic Sessions", platform: "Google Analytics" },
    { key: "ga_revenue", name: "GA Sales Revenue", platform: "Google Analytics" },
  ];

  for (let i = 1; i < sortedWeeks.length; i++) {
    const currentWeek = sortedWeeks[i];
    // Calculate 4-week trailing moving average prior to current week i
    const trailingWeeks = sortedWeeks.slice(Math.max(0, i - 4), i);
    if (trailingWeeks.length === 0) continue;

    metrics.forEach((metric) => {
      const currentVal = currentWeek[metric.key];
      if (typeof currentVal !== "number") return;

      const sum = trailingWeeks.reduce((acc, w) => {
        const val = w[metric.key];
        return acc + (typeof val === "number" ? val : 0);
      }, 0);
      const movingAvg = sum / trailingWeeks.length;

      // Ignore trivial small baselines to avoid alert spam
      if (movingAvg <= 5) return;

      const deviation = ((currentVal - movingAvg) / movingAvg) * 100;

      if (Math.abs(deviation) >= 25) {
        alerts.push({
          weekIso: currentWeek.iso,
          weekLabel: currentWeek.label,
          metricName: metric.name,
          metricKey: metric.key as string,
          currentValue: currentVal,
          movingAvgValue: movingAvg,
          deviation: deviation,
          type: deviation > 0 ? "spike" : "drop",
          platform: metric.platform,
        });
      }
    });
  }

  // Descending (most recent week first)
  return alerts.sort((a, b) => b.weekIso.localeCompare(a.weekIso));
}

interface AlertsSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  weeks: WeekData[];
  onSelectPlatformTab: (tab: "summary" | "ig" | "fb" | "tt" | "ga" | "audience" | "compare") => void;
}

export default function AlertsSidebar({ isOpen, onClose, weeks, onSelectPlatformTab }: AlertsSidebarProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [platformFilter, setPlatformFilter] = useState<"All" | "Instagram" | "Facebook" | "TikTok" | "Google Analytics">("All");
  const [typeFilter, setTypeFilter] = useState<"All" | "spike" | "drop">("All");

  const sidebarRef = useRef<HTMLDivElement>(null);

  // Close on Escape key press for accessibility
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  // Focus trapping or focus return for screen readers
  useEffect(() => {
    if (isOpen && sidebarRef.current) {
      const closeBtn = sidebarRef.current.querySelector("button");
      closeBtn?.focus();
    }
  }, [isOpen]);

  const allAlerts = calculateAlerts(weeks);

  // Filter alerts
  const filteredAlerts = allAlerts.filter((alert) => {
    const matchesSearch =
      alert.metricName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      alert.weekLabel.toLowerCase().includes(searchTerm.toLowerCase()) ||
      alert.weekIso.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesPlatform = platformFilter === "All" || alert.platform === platformFilter;
    const matchesType = typeFilter === "All" || alert.type === typeFilter;

    return matchesSearch && matchesPlatform && matchesType;
  });

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case "Instagram":
        return <Instagram className="w-4 h-4 text-pink-500" />;
      case "Facebook":
        return <Facebook className="w-4 h-4 text-blue-500" />;
      case "TikTok":
        return <Video className="w-4 h-4 text-teal-400" />;
      case "Google Analytics":
        return <LineChartIcon className="w-4 h-4 text-emerald-500" />;
      default:
        return <Bell className="w-4 h-4 text-indigo-500" />;
    }
  };

  const getPlatformTabId = (platform: string): "summary" | "ig" | "fb" | "tt" | "ga" => {
    switch (platform) {
      case "Instagram":
        return "ig";
      case "Facebook":
        return "fb";
      case "TikTok":
        return "tt";
      case "Google Analytics":
        return "ga";
      default:
        return "summary";
    }
  };

  return (
    <>
      {/* Overlay Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-slate-950/60 z-40 transition-opacity duration-300 no-print"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      {/* Slide-out Panel */}
      <div
        ref={sidebarRef}
        id="alerts-sidebar"
        role="dialog"
        aria-modal="true"
        aria-labelledby="alerts-sidebar-title"
        className={`fixed top-0 right-0 h-full w-full sm:w-[420px] bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 shadow-2xl z-50 flex flex-col transition-transform duration-300 no-print ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
              <Bell className="w-4.5 h-4.5" />
            </div>
            <div>
              <h2 id="alerts-sidebar-title" className="text-sm font-bold text-slate-800 dark:text-slate-100">
                Performance Spikes & Drops
              </h2>
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block">
                Moving Average Anomaly Detector
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Alerts Sidebar"
            className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer focus:ring-2 focus:ring-indigo-500 outline-none"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Algorithm Info Banner */}
        <div className="px-4 py-3 bg-indigo-500/5 border-b border-indigo-500/10 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400 flex items-start gap-2">
          <HelpCircle className="w-4 h-4 text-indigo-500 flex-shrink-0 mt-0.5" />
          <span>
            This tool automatically reviews chronological performance logs to flags any weekly metric that deviates more than <strong>±25%</strong> compared to its trailing 4-week moving average baseline.
          </span>
        </div>

        {/* Search and Filters */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 space-y-3 bg-slate-50/50 dark:bg-slate-950/20">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search alerts (e.g. reach, W05)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-1.5 rounded-xl border text-xs text-slate-800 dark:text-slate-100 outline-none
                dark:bg-slate-950 dark:border-slate-800 dark:focus:border-indigo-500 focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Platform</label>
              <select
                value={platformFilter}
                onChange={(e) => setPlatformFilter(e.target.value as any)}
                className="w-full px-2.5 py-1.5 rounded-lg border text-[11px] text-slate-700 dark:text-slate-300 outline-none dark:bg-slate-950 dark:border-slate-800 cursor-pointer"
              >
                <option value="All">All Channels</option>
                <option value="Instagram">Instagram</option>
                <option value="Facebook">Facebook</option>
                <option value="TikTok">TikTok</option>
                <option value="Google Analytics">Google Analytics</option>
              </select>
            </div>

            <div>
              <label className="text-[9px] uppercase font-bold text-slate-400 block mb-1">Type</label>
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value as any)}
                className="w-full px-2.5 py-1.5 rounded-lg border text-[11px] text-slate-700 dark:text-slate-300 outline-none dark:bg-slate-950 dark:border-slate-800 cursor-pointer"
              >
                <option value="All">All Types</option>
                <option value="spike">Spikes Only (+)</option>
                <option value="drop">Drops Only (-)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Alerts Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin">
          {filteredAlerts.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400 italic flex flex-col items-center justify-center gap-2">
              <AlertCircle className="w-8 h-8 text-slate-300 dark:text-slate-700" />
              <span>No alerts found matching your filters.</span>
            </div>
          ) : (
            filteredAlerts.map((alert, idx) => {
              const isSpike = alert.type === "spike";
              return (
                <div
                  key={`${alert.weekIso}-${alert.metricKey}-${idx}`}
                  onClick={() => {
                    onSelectPlatformTab(getPlatformTabId(alert.platform));
                    onClose();
                  }}
                  className="p-3.5 rounded-xl border dark:border-slate-800 border-slate-150 dark:bg-slate-950/40 bg-white hover:border-indigo-500 dark:hover:border-indigo-500 transition-all duration-200 cursor-pointer group hover:shadow-sm"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold font-mono text-slate-400 dark:text-slate-500">
                      {alert.weekIso} ({alert.weekLabel})
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                        isSpike
                          ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                          : "bg-rose-500/10 text-rose-600 dark:text-rose-400"
                      }`}
                    >
                      {isSpike ? (
                        <>
                          <TrendingUp className="w-3 h-3" />
                          +{alert.deviation.toFixed(0)}% Spike
                        </>
                      ) : (
                        <>
                          <TrendingDown className="w-3 h-3" />
                          {alert.deviation.toFixed(0)}% Drop
                        </>
                      )}
                    </span>
                  </div>

                  <div className="flex items-start gap-2">
                    <div className="p-1.5 rounded-lg dark:bg-slate-900 bg-slate-100 flex-shrink-0 mt-0.5">
                      {getPlatformIcon(alert.platform)}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                        {alert.metricName} anomaly
                      </h4>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                        Current value: <strong className="font-mono text-slate-700 dark:text-slate-300">{Math.round(alert.currentValue).toLocaleString()}</strong> vs 
                        trailing average baseline: <strong className="font-mono text-slate-700 dark:text-slate-300">{Math.round(alert.movingAvgValue).toLocaleString()}</strong>
                      </p>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/20 text-[10px] text-slate-400 text-center font-semibold uppercase tracking-wider">
          {filteredAlerts.length} Active {filteredAlerts.length === 1 ? "Anomalous Record" : "Anomalous Records"}
        </div>
      </div>
    </>
  );
}
