import { AudienceData } from "../types";
import { Users, Globe2, Building2, Flame } from "lucide-react";

interface AudienceInsightsProps {
  audience: AudienceData;
}

export default function AudienceInsights({ audience }: AudienceInsightsProps) {
  const { ig, fb, tt } = audience;

  const renderHorizontalBarList = (items: { name: string; pct: number }[], colorClass: string) => {
    if (!items || items.length === 0) {
      return (
        <div className="py-8 text-center text-xs text-slate-400 italic">
          No geolocation data available for this range.
        </div>
      );
    }

    const maxPct = Math.max(...items.map((i) => i.pct));

    return (
      <div className="space-y-3.5">
        {items.slice(0, 5).map((item, idx) => {
          const widthPct = maxPct > 0 ? (item.pct / maxPct) * 100 : 0;
          return (
            <div key={idx} className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-700 dark:text-slate-300 truncate pr-2">
                  {idx + 1}. {item.name}
                </span>
                <span className="font-mono text-slate-500 dark:text-slate-400">
                  {(item.pct * 100).toFixed(1)}%
                </span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  style={{ width: `${widthPct}%` }}
                  className={`h-full rounded-full ${colorClass} transition-all duration-500`}
                />
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const renderAgeGenderBreakdown = (
    data: { band: string; v1: number; v2: number }[] | undefined,
    genderOrder: string[] | undefined
  ) => {
    if (!data || data.length === 0) return null;

    const g1Name = genderOrder?.[0] || "Women";
    const g2Name = genderOrder?.[1] || "Men";

    // Detect platform colors (Women -> Rose, Men -> Blue)
    const isW1 = g1Name.toLowerCase().includes("women");
    const color1 = isW1 ? "bg-rose-500" : "bg-sky-500";
    const color2 = isW1 ? "bg-sky-500" : "bg-rose-500";
    const text1 = isW1 ? "text-rose-500" : "text-sky-500";
    const text2 = isW1 ? "text-sky-500" : "text-rose-500";

    const maxTotal = Math.max(...data.map((d) => d.v1 + d.v2));

    return (
      <div className="space-y-4">
        <div className="flex gap-4 text-[10px] font-bold uppercase tracking-wider mb-2">
          <span className={`flex items-center ${text1}`}>
            <span className={`w-2.5 h-2.5 rounded-full ${color1} mr-1.5`} />
            {g1Name}
          </span>
          <span className={`flex items-center ${text2}`}>
            <span className={`w-2.5 h-2.5 rounded-full ${color2} mr-1.5`} />
            {g2Name}
          </span>
        </div>

        <div className="space-y-3">
          {data.map((d) => {
            const w1 = maxTotal > 0 ? (d.v1 / maxTotal) * 100 : 0;
            const w2 = maxTotal > 0 ? (d.v2 / maxTotal) * 100 : 0;
            return (
              <div key={d.band} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-700 dark:text-slate-400">{d.band}</span>
                  <div className="flex gap-3 font-mono text-[10px]">
                    <span className={`${text1}`}>{Math.round(d.v1 * 10) / 10}%</span>
                    <span className="text-slate-300">/</span>
                    <span className={`${text2}`}>{Math.round(d.v2 * 10) / 10}%</span>
                  </div>
                </div>
                <div className="flex h-2 rounded-full overflow-hidden bg-slate-100 dark:bg-slate-800 gap-0.5">
                  <div style={{ width: `${w1}%` }} className={`${color1} rounded-l-full`} />
                  <div style={{ width: `${w2}%` }} className={`${color2} rounded-r-full`} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div id="audience-insights" className="space-y-6">
      {ig && (
        <div className="animate-fade-in-up">
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-rose-500" />
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              Instagram Audience Demographics
            </h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="p-5 rounded-2xl border dark:border-slate-800 border-slate-200 dark:bg-slate-900 bg-white">
              <h5 className="text-xs font-bold uppercase text-slate-400 mb-4 tracking-wider flex items-center">
                <Flame className="w-4 h-4 mr-1 text-rose-500" />
                Age & Gender Distribution
              </h5>
              {renderAgeGenderBreakdown(ig.age_gender, ig.gender_order)}
            </div>

            <div className="p-5 rounded-2xl border dark:border-slate-800 border-slate-200 dark:bg-slate-900 bg-white">
              <h5 className="text-xs font-bold uppercase text-slate-400 mb-4 tracking-wider flex items-center">
                <Globe2 className="w-4 h-4 mr-1 text-rose-500" />
                Top Countries
              </h5>
              {renderHorizontalBarList(ig.top_countries, "bg-rose-500")}
            </div>

            <div className="p-5 rounded-2xl border dark:border-slate-800 border-slate-200 dark:bg-slate-900 bg-white">
              <h5 className="text-xs font-bold uppercase text-slate-400 mb-4 tracking-wider flex items-center">
                <Building2 className="w-4 h-4 mr-1 text-rose-500" />
                Top Cities
              </h5>
              {renderHorizontalBarList(ig.top_cities, "bg-pink-400")}
            </div>
          </div>
        </div>
      )}

      {fb && (
        <div className="animate-fade-in-up">
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-sky-500" />
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              Facebook Audience Demographics
            </h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="p-5 rounded-2xl border dark:border-slate-800 border-slate-200 dark:bg-slate-900 bg-white">
              <h5 className="text-xs font-bold uppercase text-slate-400 mb-4 tracking-wider flex items-center">
                <Flame className="w-4 h-4 mr-1 text-sky-500" />
                Age & Gender Distribution
              </h5>
              {renderAgeGenderBreakdown(fb.age_gender, fb.gender_order)}
            </div>

            <div className="p-5 rounded-2xl border dark:border-slate-800 border-slate-200 dark:bg-slate-900 bg-white">
              <h5 className="text-xs font-bold uppercase text-slate-400 mb-4 tracking-wider flex items-center">
                <Globe2 className="w-4 h-4 mr-1 text-sky-500" />
                Top Countries
              </h5>
              {renderHorizontalBarList(fb.top_countries, "bg-sky-500")}
            </div>

            <div className="p-5 rounded-2xl border dark:border-slate-800 border-slate-200 dark:bg-slate-900 bg-white flex flex-col justify-center items-center text-center">
              <Globe2 className="w-8 h-8 text-slate-300 dark:text-slate-700 mb-2" />
              <p className="text-xs font-semibold text-slate-500">Cities Data Unavailable</p>
              <p className="text-[10px] text-slate-400 mt-1 max-w-[200px]">
                Facebook city-level metrics require a full raw export from Meta Business Suite.
              </p>
            </div>
          </div>
        </div>
      )}

      {tt?.daily && tt.daily.length > 0 && (
        <div className="animate-fade-in-up">
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-teal-400" />
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              TikTok Daily Acquisition Breakdown
            </h4>
          </div>

          <div className="p-5 rounded-2xl border dark:border-slate-800 border-slate-200 dark:bg-slate-900 bg-white overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b dark:border-slate-800 border-slate-100 text-slate-400 font-bold uppercase tracking-wider">
                    <th className="py-2.5 px-4">Date</th>
                    <th className="py-2.5 px-4 text-right">New Followers</th>
                    <th className="py-2.5 px-4 text-right">Total Followers</th>
                    <th className="py-2.5 px-4 text-right">Daily Reach</th>
                    <th className="py-2.5 px-4 text-right">Daily Engagements</th>
                  </tr>
                </thead>
                <tbody className="divide-y dark:divide-slate-800 divide-slate-100 font-mono">
                  {tt.daily.slice(0, 10).map((d) => (
                    <tr key={d.date} className="hover:bg-slate-50 dark:hover:bg-slate-950/40 transition">
                      <td className="py-2 px-4 text-slate-700 dark:text-slate-300">{d.date}</td>
                      <td className="py-2 px-4 text-right text-teal-500 font-bold">+{d.new_flw}</td>
                      <td className="py-2 px-4 text-right text-slate-700 dark:text-slate-300 font-bold">
                        {Math.round(d.total_flw).toLocaleString()}
                      </td>
                      <td className="py-2 px-4 text-right text-slate-500 dark:text-slate-400">
                        {Math.round(d.reached).toLocaleString()}
                      </td>
                      <td className="py-2 px-4 text-right text-slate-500 dark:text-slate-400">
                        {Math.round(d.engaged).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {tt.daily.length > 10 && (
              <p className="text-[10px] text-slate-400 mt-2 text-center">
                Showing the most recent 10 TikTok daily log entries.
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
