import { ArrowUpRight, ArrowDownRight, Eye, Heart, Share2, Users, Target, MousePointerClick, TrendingUp, DollarSign, Activity, Percent } from "lucide-react";
import { WeekData } from "../types";

interface ChannelKpiCardsProps {
  channel: "ig" | "fb" | "tt" | "ga";
  filteredWeeks: WeekData[];
  compareWeeks: WeekData[];
  compareMode: boolean;
}

export default function ChannelKpiCards({
  channel,
  filteredWeeks,
  compareWeeks,
  compareMode,
}: ChannelKpiCardsProps) {
  const getSum = (weeksList: WeekData[], key: keyof WeekData) => {
    return weeksList.reduce((sum, w) => sum + (Number(w[key]) || 0), 0);
  };

  const getDoubleSum = (weeksList: WeekData[], key1: keyof WeekData, key2: keyof WeekData) => {
    return weeksList.reduce((sum, w) => sum + (Number(w[key1]) || 0) + (Number(w[key2]) || 0), 0);
  };

  const getTripleSum = (weeksList: WeekData[], key1: keyof WeekData, key2: keyof WeekData, key3: keyof WeekData) => {
    return weeksList.reduce((sum, w) => sum + (Number(w[key1]) || 0) + (Number(w[key2]) || 0) + (Number(w[key3]) || 0), 0);
  };

  // Helper to format values
  const formatValue = (val: number, isCurrency = false, isPercent = false) => {
    if (isPercent) {
      return `${val.toFixed(2)}%`;
    }
    if (isCurrency) {
      return `$${Math.round(val).toLocaleString()}`;
    }
    return Math.round(val).toLocaleString();
  };

  // Helper to calculate trend
  const calculateTrend = (curr: number, prev: number) => {
    if (prev === 0) return null;
    const diff = curr - prev;
    const pct = (diff / prev) * 100;
    return {
      isUp: diff >= 0,
      text: `${diff >= 0 ? "+" : ""}${pct.toFixed(1)}%`,
    };
  };

  // Build the metrics dynamically based on the active channel
  let kpiData: Array<{
    id: string;
    title: string;
    value: string;
    icon: any;
    colorClass: string;
    textColor: string;
    bgColor: string;
    trend: { isUp: boolean; text: string } | null;
  }> = [];

  const hasCompareData = compareMode && compareWeeks.length > 0;

  if (channel === "ig") {
    // 1. Instagram Reach
    const currReach = getSum(filteredWeeks, "ig_reach");
    const prevReach = getSum(compareWeeks, "ig_reach");
    const reachTrend = hasCompareData ? calculateTrend(currReach, prevReach) : null;

    // 2. Instagram Impressions / Views
    const currViews = getSum(filteredWeeks, "ig_views");
    const prevViews = getSum(compareWeeks, "ig_views");
    const viewsTrend = hasCompareData ? calculateTrend(currViews, prevViews) : null;

    // 3. Instagram Engagements / Interactions
    const currInter = getSum(filteredWeeks, "ig_inter");
    const prevInter = getSum(compareWeeks, "ig_inter");
    const interTrend = hasCompareData ? calculateTrend(currInter, prevInter) : null;

    // 4. Instagram New Follows
    const currFollows = getSum(filteredWeeks, "ig_follows");
    const prevFollows = getSum(compareWeeks, "ig_follows");
    const followsTrend = hasCompareData ? calculateTrend(currFollows, prevFollows) : null;

    kpiData = [
      {
        id: "ig-reach",
        title: "Total Account Reach",
        value: formatValue(currReach),
        icon: Target,
        colorClass: "from-pink-500 to-rose-500",
        textColor: "text-pink-500",
        bgColor: "bg-pink-500/10 dark:bg-pink-500/20",
        trend: reachTrend,
      },
      {
        id: "ig-views",
        title: "Content Impressions",
        value: formatValue(currViews),
        icon: Eye,
        colorClass: "from-purple-500 to-indigo-500",
        textColor: "text-purple-500",
        bgColor: "bg-purple-500/10 dark:bg-purple-500/20",
        trend: viewsTrend,
      },
      {
        id: "ig-inter",
        title: "Weekly Engagement",
        value: formatValue(currInter),
        icon: Activity,
        colorClass: "from-rose-400 to-red-500",
        textColor: "text-rose-500",
        bgColor: "bg-rose-500/10 dark:bg-rose-500/20",
        trend: interTrend,
      },
      {
        id: "ig-follows",
        title: "Follower Growth",
        value: `+${formatValue(currFollows)}`,
        icon: Users,
        colorClass: "from-fuchsia-400 to-pink-500",
        textColor: "text-fuchsia-500",
        bgColor: "bg-fuchsia-500/10 dark:bg-fuchsia-500/20",
        trend: followsTrend,
      },
    ];
  } else if (channel === "fb") {
    // 1. Facebook Impressions / Views
    const currViews = getSum(filteredWeeks, "fb_views");
    const prevViews = getSum(compareWeeks, "fb_views");
    const viewsTrend = hasCompareData ? calculateTrend(currViews, prevViews) : null;

    // 2. Facebook Profile Visits
    const currVisits = getSum(filteredWeeks, "fb_visits");
    const prevVisits = getSum(compareWeeks, "fb_visits");
    const visitsTrend = hasCompareData ? calculateTrend(currVisits, prevVisits) : null;

    // 3. Facebook Post Engagements
    const currInter = getSum(filteredWeeks, "fb_inter");
    const prevInter = getSum(compareWeeks, "fb_inter");
    const interTrend = hasCompareData ? calculateTrend(currInter, prevInter) : null;

    // 4. Facebook Link Clicks
    const currClicks = getSum(filteredWeeks, "fb_clicks");
    const prevClicks = getSum(compareWeeks, "fb_clicks");
    const clicksTrend = hasCompareData ? calculateTrend(currClicks, prevClicks) : null;

    kpiData = [
      {
        id: "fb-views",
        title: "Impressions & Views",
        value: formatValue(currViews),
        icon: Eye,
        colorClass: "from-blue-500 to-indigo-600",
        textColor: "text-blue-500",
        bgColor: "bg-blue-500/10 dark:bg-blue-500/20",
        trend: viewsTrend,
      },
      {
        id: "fb-visits",
        title: "Profile Visits",
        value: formatValue(currVisits),
        icon: Users,
        colorClass: "from-sky-400 to-blue-500",
        textColor: "text-sky-500",
        bgColor: "bg-sky-500/10 dark:bg-sky-500/20",
        trend: visitsTrend,
      },
      {
        id: "fb-inter",
        title: "Post Engagements",
        value: formatValue(currInter),
        icon: Activity,
        colorClass: "from-indigo-400 to-blue-600",
        textColor: "text-indigo-500",
        bgColor: "bg-indigo-500/10 dark:bg-indigo-500/20",
        trend: interTrend,
      },
      {
        id: "fb-clicks",
        title: "Link Clicks",
        value: formatValue(currClicks),
        icon: MousePointerClick,
        colorClass: "from-blue-600 to-sky-500",
        textColor: "text-blue-600",
        bgColor: "bg-blue-600/10 dark:bg-blue-600/20",
        trend: clicksTrend,
      },
    ];
  } else if (channel === "tt") {
    // 1. TikTok Video Views
    const currViews = getSum(filteredWeeks, "tt_views");
    const prevViews = getSum(compareWeeks, "tt_views");
    const viewsTrend = hasCompareData ? calculateTrend(currViews, prevViews) : null;

    // 2. TikTok Net Growth
    const currGrowth = getSum(filteredWeeks, "tt_net_growth");
    const prevGrowth = getSum(compareWeeks, "tt_net_growth");
    const growthTrend = hasCompareData ? calculateTrend(currGrowth, prevGrowth) : null;

    // 3. TikTok Engagements (likes + comments + shares)
    const currEng = getTripleSum(filteredWeeks, "tt_likes", "tt_comments", "tt_shares");
    const prevEng = getTripleSum(compareWeeks, "tt_likes", "tt_comments", "tt_shares");
    const engTrend = hasCompareData ? calculateTrend(currEng, prevEng) : null;

    // 4. TikTok Website Clicks
    const currClicks = getSum(filteredWeeks, "tt_website_clicks");
    const prevClicks = getSum(compareWeeks, "tt_website_clicks");
    const clicksTrend = hasCompareData ? calculateTrend(currClicks, prevClicks) : null;

    kpiData = [
      {
        id: "tt-views",
        title: "TikTok Video Views",
        value: formatValue(currViews),
        icon: Eye,
        colorClass: "from-teal-400 to-emerald-500",
        textColor: "text-teal-500",
        bgColor: "bg-teal-500/10 dark:bg-teal-500/20",
        trend: viewsTrend,
      },
      {
        id: "tt-growth",
        title: "Net Followers Gained",
        value: `${currGrowth >= 0 ? "+" : ""}${formatValue(currGrowth)}`,
        icon: Users,
        colorClass: "from-emerald-400 to-teal-600",
        textColor: "text-emerald-500",
        bgColor: "bg-emerald-500/10 dark:bg-emerald-500/20",
        trend: growthTrend,
      },
      {
        id: "tt-eng",
        title: "Total Engagement",
        value: formatValue(currEng),
        icon: Heart,
        colorClass: "from-rose-400 to-pink-500",
        textColor: "text-rose-500",
        bgColor: "bg-rose-500/10 dark:bg-rose-500/20",
        trend: engTrend,
      },
      {
        id: "tt-clicks",
        title: "Website Link Clicks",
        value: formatValue(currClicks),
        icon: MousePointerClick,
        colorClass: "from-teal-500 to-cyan-500",
        textColor: "text-teal-600",
        bgColor: "bg-teal-600/10 dark:bg-teal-600/20",
        trend: clicksTrend,
      },
    ];
  } else if (channel === "ga") {
    // 1. GA Sessions
    const currSessions = getSum(filteredWeeks, "ga_sessions");
    const prevSessions = getSum(compareWeeks, "ga_sessions");
    const sessionsTrend = hasCompareData ? calculateTrend(currSessions, prevSessions) : null;

    // 2. GA Key Events / Conversions
    const currConvs = getSum(filteredWeeks, "ga_key_events");
    const prevConvs = getSum(compareWeeks, "ga_key_events");
    const convsTrend = hasCompareData ? calculateTrend(currConvs, prevConvs) : null;

    // 3. GA Conversion Rate %
    const currCvr = currSessions > 0 ? (currConvs / currSessions) * 100 : 0;
    const prevCvr = prevSessions > 0 ? (prevConvs / prevSessions) * 100 : 0;
    const cvrTrend = hasCompareData ? calculateTrend(currCvr, prevCvr) : null;

    // 4. GA Revenue
    const currRevenue = getSum(filteredWeeks, "ga_revenue");
    const prevRevenue = getSum(compareWeeks, "ga_revenue");
    const revenueTrend = hasCompareData ? calculateTrend(currRevenue, prevRevenue) : null;

    kpiData = [
      {
        id: "ga-sessions",
        title: "Inbound Sessions",
        value: formatValue(currSessions),
        icon: TrendingUp,
        colorClass: "from-emerald-400 to-green-600",
        textColor: "text-emerald-500",
        bgColor: "bg-emerald-500/10 dark:bg-emerald-500/20",
        trend: sessionsTrend,
      },
      {
        id: "ga-convs",
        title: "Ecommerce Sales",
        value: formatValue(currConvs),
        icon: Target,
        colorClass: "from-green-500 to-teal-500",
        textColor: "text-green-600",
        bgColor: "bg-green-500/10 dark:bg-green-500/20",
        trend: convsTrend,
      },
      {
        id: "ga-cvr",
        title: "Conversion Rate (CVR)",
        value: formatValue(currCvr, false, true),
        icon: Percent,
        colorClass: "from-teal-400 to-green-500",
        textColor: "text-teal-500",
        bgColor: "bg-teal-500/10 dark:bg-teal-500/20",
        trend: cvrTrend,
      },
      {
        id: "ga-revenue",
        title: "Total Revenue USD",
        value: formatValue(currRevenue, true),
        icon: DollarSign,
        colorClass: "from-emerald-500 to-teal-600",
        textColor: "text-emerald-600",
        bgColor: "bg-emerald-500/10 dark:bg-emerald-500/20",
        trend: revenueTrend,
      },
    ];
  }

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {kpiData.map((kpi) => {
        const Icon = kpi.icon;
        return (
          <div
            key={kpi.id}
            className="p-4 rounded-xl border transition-all duration-300 relative overflow-hidden group hover:shadow-md
              dark:bg-slate-900 dark:border-slate-800 dark:hover:border-slate-700 bg-white border-slate-200"
          >
            {/* Top color bar */}
            <div className={`absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r ${kpi.colorClass}`} />

            <div className="flex justify-between items-start mb-2.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                {kpi.title}
              </span>
              <div className={`p-1.5 rounded-lg ${kpi.bgColor} ${kpi.textColor}`}>
                <Icon className="w-4 h-4" />
              </div>
            </div>

            <div className="flex items-baseline justify-between">
              <span className="text-xl font-bold font-mono tracking-tight text-slate-800 dark:text-slate-100">
                {kpi.value}
              </span>
              {kpi.trend && (
                <span
                  className={`flex items-center font-bold font-mono text-[10px] px-1.5 py-0.5 rounded-full ${
                    kpi.trend.isUp
                      ? "text-emerald-600 bg-emerald-50 dark:text-emerald-400 dark:bg-emerald-500/10"
                      : "text-rose-600 bg-rose-50 dark:text-rose-400 dark:bg-rose-500/10"
                  }`}
                  title="Period-to-period percent change"
                >
                  {kpi.trend.isUp ? (
                    <ArrowUpRight className="w-3 h-3 mr-0.5 flex-shrink-0" />
                  ) : (
                    <ArrowDownRight className="w-3 h-3 mr-0.5 flex-shrink-0" />
                  )}
                  {kpi.trend.text}
                </span>
              )}
            </div>
            {compareMode && (
              <p className="text-[9px] text-slate-400 dark:text-slate-500 font-semibold font-mono mt-1 text-right">
                vs. Prev. Period
              </p>
            )}
          </div>
        );
      })}
    </div>
  );
}
