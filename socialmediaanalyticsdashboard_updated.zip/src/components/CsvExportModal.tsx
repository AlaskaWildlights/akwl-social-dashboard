import { useState } from "react";
import { X, CheckSquare, Square, Download, HelpCircle } from "lucide-react";
import { WeekData } from "../types";

interface CsvExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  filteredWeeks: WeekData[];
  startWeek: string;
  endWeek: string;
}

interface ColumnMetadata {
  key: string;
  label: string;
  group: "Global" | "Instagram" | "Facebook" | "TikTok" | "Google Analytics";
}

const COLUMN_OPTIONS: ColumnMetadata[] = [
  // Instagram Group
  { key: "ig_reach", label: "Instagram Reach", group: "Instagram" },
  { key: "ig_views", label: "Instagram Views", group: "Instagram" },
  { key: "ig_follows", label: "Instagram Follows", group: "Instagram" },
  { key: "ig_visits", label: "Instagram Visits", group: "Instagram" },
  { key: "ig_inter", label: "Instagram Engagements", group: "Instagram" },
  { key: "ig_clicks", label: "Instagram Clicks", group: "Instagram" },
  { key: "ig_eng", label: "Instagram Engagement Rate %", group: "Instagram" },
  { key: "ig_followers", label: "Instagram Followers", group: "Instagram" },
  
  // Facebook Group
  { key: "fb_views", label: "Facebook Views", group: "Facebook" },
  { key: "fb_visits", label: "Facebook Visits", group: "Facebook" },
  { key: "fb_viewers", label: "Facebook Viewers", group: "Facebook" },
  { key: "fb_follows", label: "Facebook Follows", group: "Facebook" },
  { key: "fb_inter", label: "Facebook Engagements", group: "Facebook" },
  { key: "fb_clicks", label: "Facebook Clicks", group: "Facebook" },

  // TikTok Group
  { key: "tt_views", label: "TikTok Video Views", group: "TikTok" },
  { key: "tt_reach", label: "TikTok Reach", group: "TikTok" },
  { key: "tt_profile_views", label: "TikTok Profile Views", group: "TikTok" },
  { key: "tt_net_growth", label: "TikTok Net Followers Growth", group: "TikTok" },
  { key: "tt_likes", label: "TikTok Video Likes", group: "TikTok" },
  { key: "tt_comments", label: "TikTok Video Comments", group: "TikTok" },
  { key: "tt_shares", label: "TikTok Video Shares", group: "TikTok" },
  { key: "tt_website_clicks", label: "TikTok Website Clicks", group: "TikTok" },
  { key: "tt_followers", label: "TikTok Followers", group: "TikTok" },

  // Google Analytics Group
  { key: "ga_sessions", label: "GA Sessions", group: "Google Analytics" },
  { key: "ga_key_events", label: "GA Conversions", group: "Google Analytics" },
  { key: "ga_revenue", label: "GA Revenue USD", group: "Google Analytics" },
];

export default function CsvExportModal({
  isOpen,
  onClose,
  filteredWeeks,
  startWeek,
  endWeek,
}: CsvExportModalProps) {
  const [selectedKeys, setSelectedKeys] = useState<Set<string>>(
    new Set(COLUMN_OPTIONS.map((c) => c.key))
  );

  if (!isOpen) return null;

  const toggleColumn = (key: string) => {
    setSelectedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  };

  const handleSelectAll = () => {
    setSelectedKeys(new Set(COLUMN_OPTIONS.map((c) => c.key)));
  };

  const handleClearAll = () => {
    setSelectedKeys(new Set());
  };

  const handleSelectGroup = (groupName: string) => {
    setSelectedKeys((prev) => {
      const next = new Set(prev);
      const groupKeys = COLUMN_OPTIONS.filter((c) => c.group === groupName).map((c) => c.key);
      const allInGroupSelected = groupKeys.every((key) => next.has(key));
      
      groupKeys.forEach((key) => {
        if (allInGroupSelected) {
          next.delete(key);
        } else {
          next.add(key);
        }
      });
      return next;
    });
  };

  const executeExport = () => {
    if (filteredWeeks.length === 0) return;

    // Fixed columns that are always exported
    const headers = ["Week (ISO)", "Week Label"];
    const activeColumns = COLUMN_OPTIONS.filter((col) => selectedKeys.has(col.key));
    
    // Add active column labels
    activeColumns.forEach((col) => {
      headers.push(col.label);
    });

    const rows = filteredWeeks.map((w) => {
      const baseRow: (string | number)[] = [w.iso, `"${w.label.replace(/"/g, '""')}"`];
      
      activeColumns.forEach((col) => {
        const k = col.key;
        if (k === "ig_eng") {
          baseRow.push((w.ig_eng * 100).toFixed(2));
        } else {
          const val = w[k as keyof WeekData];
          if (typeof val === "number") {
            baseRow.push(val);
          } else {
            baseRow.push(val ? String(val) : "");
          }
        }
      });
      return baseRow;
    });

    const csvString = [headers.join(","), ...rows.map((e) => e.join(","))].join("\n");
    const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Alaska_Wild_Lights_Custom_Report_${startWeek}_to_${endWeek}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    onClose();
  };

  const groups = Array.from(new Set(COLUMN_OPTIONS.map((c) => c.group)));

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 no-print"
      role="dialog"
      aria-modal="true"
      aria-labelledby="csv-export-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Download className="w-5 h-5 text-indigo-500" />
            <h3 id="csv-export-title" className="text-sm font-bold text-slate-800 dark:text-slate-100">
              Customize CSV Columns & Metrics
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer focus:ring-2 focus:ring-indigo-500 outline-none"
            aria-label="Close export dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <p className="text-slate-500 dark:text-slate-400 font-medium">
              Report window: <strong className="font-semibold text-indigo-500 dark:text-indigo-400">{startWeek} to {endWeek}</strong> ({filteredWeeks.length} weeks selected).
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleSelectAll}
                className="px-2 py-1 text-[10px] font-bold rounded-lg border dark:border-slate-800 bg-slate-50 dark:bg-slate-950 dark:text-slate-300 text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-850"
              >
                Select All
              </button>
              <button
                type="button"
                onClick={handleClearAll}
                className="px-2 py-1 text-[10px] font-bold rounded-lg border dark:border-slate-800 bg-slate-50 dark:bg-slate-950 dark:text-slate-300 text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-850"
              >
                Clear All
              </button>
            </div>
          </div>

          {/* Grouped Checkboxes */}
          <div className="max-h-[350px] overflow-y-auto pr-1 space-y-4 scrollbar-thin">
            {groups.map((groupName) => {
              const groupCols = COLUMN_OPTIONS.filter((c) => c.group === groupName);
              const groupSelectedCount = groupCols.filter((col) => selectedKeys.has(col.key)).length;
              const allGroupSelected = groupSelectedCount === groupCols.length;

              return (
                <div
                  key={groupName}
                  className="p-3 rounded-xl border dark:border-slate-800 border-slate-100 dark:bg-slate-950/20 bg-slate-50/50"
                >
                  <div className="flex items-center justify-between mb-2.5 pb-1 border-b dark:border-slate-800 border-slate-100">
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      {groupName}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleSelectGroup(groupName)}
                      className="text-[10px] font-semibold text-indigo-500 hover:text-indigo-600 dark:text-indigo-400 cursor-pointer"
                    >
                      {allGroupSelected ? "Deselect Group" : "Select Group"} ({groupSelectedCount}/{groupCols.length})
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {groupCols.map((col) => {
                      const isChecked = selectedKeys.has(col.key);
                      return (
                        <button
                          key={col.key}
                          type="button"
                          onClick={() => toggleColumn(col.key)}
                          className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left text-xs transition-all duration-150 cursor-pointer border
                            dark:hover:bg-slate-850 hover:bg-slate-50
                            dark:border-transparent border-transparent"
                        >
                          {isChecked ? (
                            <CheckSquare className="w-4 h-4 text-indigo-500 flex-shrink-0" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-300 dark:text-slate-700 flex-shrink-0" />
                          )}
                          <span className={isChecked ? "font-semibold text-slate-800 dark:text-slate-100" : "text-slate-500 dark:text-slate-400"}>
                            {col.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-3 bg-amber-50 dark:bg-amber-500/10 border border-amber-200/50 dark:border-amber-500/20 rounded-xl flex items-start gap-2 text-[11px] text-amber-700 dark:text-amber-300">
            <HelpCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-amber-600 dark:text-amber-400" />
            <div>
              <strong className="font-bold block">Temporal & Meta Columns Included Automatically</strong>
              <span>The exported CSV will always include the first two columns (<strong>Week (ISO)</strong> and <strong>Week Label</strong>) to maintain complete time-series and report readability.</span>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border dark:border-slate-800 text-slate-500 hover:text-slate-600 dark:hover:text-slate-300 rounded-xl cursor-pointer text-xs font-bold bg-white dark:bg-slate-900"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={executeExport}
            disabled={selectedKeys.size === 0}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl cursor-pointer flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            Generate Custom CSV
          </button>
        </div>
      </div>
    </div>
  );
}
