import { useState } from "react";
import { Download, X, AlertCircle, FileText, Loader2 } from "lucide-react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetRefId: string; // The ID of the container we want to export to PDF
}

const colorCache = new Map<string, string>();

function convertOklchToRgb(colorStr: string): string {
  if (colorCache.has(colorStr)) {
    return colorCache.get(colorStr)!;
  }
  try {
    const canvas = document.createElement("canvas");
    canvas.width = 1;
    canvas.height = 1;
    const ctx = canvas.getContext("2d");
    if (!ctx) return "rgb(255, 255, 255)";
    ctx.fillStyle = colorStr;
    ctx.fillRect(0, 0, 1, 1);
    const [r, g, b, a] = ctx.getImageData(0, 0, 1, 1).data;
    const converted = a === 255
      ? `rgb(${r}, ${g}, ${b})`
      : `rgba(${r}, ${g}, ${b}, ${(a / 255).toFixed(3)})`;
    colorCache.set(colorStr, converted);
    return converted;
  } catch (e) {
    return "rgb(255, 255, 255)";
  }
}

function replaceOklchInString(str: string): string {
  if (!str) return str;
  if (!str.includes("oklch") && !str.includes("oklab")) {
    return str;
  }
  return str.replace(/(oklch|oklab)\([^)]+\)/g, (match) => {
    return convertOklchToRgb(match);
  });
}

export default function ExportModal({ isOpen, onClose, targetRefId }: ExportModalProps) {
  const [fileName, setFileName] = useState("Social_Performance_Executive_Report");
  const [paperSize, setPaperSize] = useState<"a4" | "letter">("a4");
  const [orientation, setOrientation] = useState<"p" | "l">("l");
  const [isExporting, setIsExporting] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  if (!isOpen) return null;

  const handleExport = async () => {
    setIsExporting(true);
    setErrorMsg("");

    try {
      const element = document.getElementById(targetRefId);
      if (!element) {
        throw new Error("Report container not found in DOM.");
      }

      // Temporarily patch getComputedStyle to convert OKLCH colors to RGB/RGBA
      const originalGetComputedStyle = window.getComputedStyle;
      window.getComputedStyle = function (elt, pseudoElt) {
        const style = originalGetComputedStyle(elt, pseudoElt);
        return new Proxy(style, {
          get(target, prop, receiver) {
            if (prop === "getPropertyValue") {
              return function (propertyName: string) {
                const val = target.getPropertyValue(propertyName);
                return replaceOklchInString(val);
              };
            }
            const val = Reflect.get(target, prop, receiver);
            if (typeof val === "string") {
              return replaceOklchInString(val);
            }
            if (typeof val === "function") {
              return val.bind(target);
            }
            return val;
          },
        });
      };

      let canvas;
      try {
        // Capture canvas
        canvas = await html2canvas(element, {
          scale: 2, // Retains high resolution
          useCORS: true,
          logging: false,
          backgroundColor: document.documentElement.classList.contains("dark") ? "#0f172a" : "#ffffff",
        });
      } finally {
        // Restore original getComputedStyle
        window.getComputedStyle = originalGetComputedStyle;
      }

      const imgData = canvas.toDataURL("image/png");

      // Calculate sizes
      const pdf = new jsPDF({
        orientation: orientation,
        unit: "mm",
        format: paperSize,
      });

      const imgWidth = orientation === "l" ? (paperSize === "a4" ? 297 : 279) : (paperSize === "a4" ? 210 : 216);
      const pageHeight = orientation === "l" ? (paperSize === "a4" ? 210 : 216) : (paperSize === "a4" ? 297 : 279);
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`${fileName}.pdf`);
      setIsExporting(false);
      onClose();
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err?.message || "An error occurred while generating your PDF report. Please try again.");
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/75 flex items-center justify-center z-50 p-4 animate-fade-in-up">
      <div className="w-full max-w-md rounded-2xl border dark:bg-slate-900 bg-white dark:border-slate-800 border-slate-200 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b dark:border-slate-800 border-slate-100">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-500" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">
              Export High-Fidelity PDF Report
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-5 space-y-4">
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
              File Name
            </label>
            <input
              type="text"
              value={fileName}
              onChange={(e) => setFileName(e.target.value)}
              placeholder="Quarterly_Report"
              className="w-full px-3 py-1.5 rounded-xl border text-xs text-slate-800 dark:text-slate-100 outline-none
                dark:bg-slate-950 dark:border-slate-800 dark:focus:border-indigo-500 focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                Paper Size
              </label>
              <select
                value={paperSize}
                onChange={(e) => setPaperSize(e.target.value as "a4" | "letter")}
                className="w-full px-3 py-1.5 rounded-xl border text-xs text-slate-800 dark:text-slate-100 outline-none cursor-pointer
                  dark:bg-slate-950 dark:border-slate-800 dark:focus:border-indigo-500 focus:border-indigo-500"
              >
                <option value="a4">A4 (Standard)</option>
                <option value="letter">Letter (US)</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                Orientation
              </label>
              <select
                value={orientation}
                onChange={(e) => setOrientation(e.target.value as "p" | "l")}
                className="w-full px-3 py-1.5 rounded-xl border text-xs text-slate-800 dark:text-slate-100 outline-none cursor-pointer
                  dark:bg-slate-950 dark:border-slate-800 dark:focus:border-indigo-500 focus:border-indigo-500"
              >
                <option value="l">Landscape (Horizontal)</option>
                <option value="p">Portrait (Vertical)</option>
              </select>
            </div>
          </div>

          <div className="p-4 rounded-xl dark:bg-slate-950/40 bg-slate-50 border dark:border-slate-800 border-slate-100 flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-indigo-500 flex-shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
              This exporter utilizes <strong>jsPDF</strong> and <strong>html2canvas</strong> vector render mappings to snapshot your workspace. All dynamic Recharts, metrics, and tables will maintain crisp resolutions on exports.
            </p>
          </div>

          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-500 font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-5 border-t dark:border-slate-800 border-slate-100 dark:bg-slate-950/20 bg-slate-50/50 flex justify-end gap-3">
          <button
            onClick={onClose}
            disabled={isExporting}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:text-slate-700 disabled:opacity-50 cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleExport}
            disabled={isExporting}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-md hover:shadow-lg transition flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
          >
            {isExporting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Generating PDF...
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                Download Report
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
