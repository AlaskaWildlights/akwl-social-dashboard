import { useState, useEffect } from "react";

interface GaugeMeterProps {
  value: number;
  target: number;
  title: string;
  unit?: string;
  color: string;
}

export default function GaugeMeter({ value, target, title, unit = "", color }: GaugeMeterProps) {
  const [animatedValue, setAnimatedValue] = useState(0);

  useEffect(() => {
    // Elegant transition effect on values update
    const timer = setTimeout(() => {
      setAnimatedValue(value);
    }, 150);
    return () => clearTimeout(timer);
  }, [value]);

  const pct = Math.min(100, Math.max(0, (animatedValue / target) * 100));
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  // A semi-circle has half the circumference
  const strokeDashoffset = (circumference / 2) - (pct / 100) * (circumference / 2);

  return (
    <div className="flex flex-col items-center justify-center p-5 rounded-2xl border transition-all duration-300 relative overflow-hidden group hover-glow
      dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 hover:shadow-md animate-fade-in-up">
      <div className="text-center mb-3">
        <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">
          {title}
        </span>
      </div>

      <div className="relative w-36 h-20 flex items-center justify-center overflow-hidden">
        <svg className="w-full h-full transform -rotate-180" viewBox="0 0 100 50">
          {/* Base Background Track */}
          <path
            d="M 12 50 A 38 38 0 0 1 88 50"
            fill="none"
            stroke="rgba(148, 163, 184, 0.12)"
            strokeWidth="8"
            strokeLinecap="round"
          />
          {/* Active Highlight Arc */}
          <path
            d="M 12 50 A 38 38 0 0 1 88 50"
            fill="none"
            stroke={color}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={circumference / 2}
            strokeDashoffset={strokeDashoffset}
            className="transition-all duration-1000 ease-out"
          />
        </svg>

        {/* Central Percent Display */}
        <div className="absolute bottom-1 text-center">
          <span className="text-lg font-extrabold font-mono text-slate-800 dark:text-slate-100">
            {pct.toFixed(1)}%
          </span>
          <span className="text-[9px] font-semibold text-slate-400 block mt-0.5">
            {Math.round(animatedValue).toLocaleString()}{unit} / {target.toLocaleString()}{unit}
          </span>
        </div>
      </div>
    </div>
  );
}
