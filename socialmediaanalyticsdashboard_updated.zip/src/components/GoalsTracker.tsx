import { useState } from "react";
import { Goals, WeekData } from "../types";
import { Target, Award, Zap } from "lucide-react";

interface GoalsTrackerProps {
  currentWeek: WeekData;
  initialGoals: Goals;
}

export default function GoalsTracker({ currentWeek, initialGoals }: GoalsTrackerProps) {
  // Local state for interactive target custom ranges
  const [igFollowersTarget, setIgFollowersTarget] = useState(initialGoals.ig_followers || 1500);
  const [igEngRateTarget, setIgEngRateTarget] = useState(initialGoals.ig_eng_rate || 6);
  const [ttFollowersTarget, setTtFollowersTarget] = useState(initialGoals.tt_followers || 200);

  // Currents
  const currentIgFollowers = currentWeek.ig_followers;
  const currentIgEng = currentWeek.ig_eng * 100; // translate into %
  const currentTtFollowers = currentWeek.tt_followers;

  const calculateProgress = (curr: number, target: number) => {
    if (target === 0) return 0;
    return Math.min(100, Math.max(0, (curr / target) * 100));
  };

  const igFollowersPct = calculateProgress(currentIgFollowers, igFollowersTarget);
  const igEngPct = calculateProgress(currentIgEng, igEngRateTarget);
  const ttFollowersPct = calculateProgress(currentTtFollowers, ttFollowersTarget);

  const getStatusText = (pct: number) => {
    if (pct >= 100) return { label: "Goal Achieved!", color: "text-emerald-500", desc: "Outstanding performance." };
    if (pct >= 80) return { label: "Almost There", color: "text-indigo-400", desc: "Keep pushing, you're so close!" };
    if (pct >= 50) return { label: "Halfway There", color: "text-amber-500", desc: "Steady progress made." };
    return { label: "In Progress", color: "text-rose-400", desc: "Requires further optimization." };
  };

  const goalsList = [
    {
      id: "ig-followers",
      label: "Instagram Followers Goal",
      current: currentIgFollowers,
      target: igFollowersTarget,
      setTarget: setIgFollowersTarget,
      pct: igFollowersPct,
      min: 500,
      max: 3000,
      step: 50,
      formatter: (val: number) => `${Math.round(val).toLocaleString()}`,
      color: "from-pink-500 to-rose-500",
      accentClass: "bg-rose-500",
    },
    {
      id: "ig-eng",
      label: "Engagement Rate Goal (IG)",
      current: currentIgEng,
      target: igEngRateTarget,
      setTarget: setIgEngRateTarget,
      pct: igEngPct,
      min: 1,
      max: 20,
      step: 0.5,
      formatter: (val: number) => `${val.toFixed(1)}%`,
      color: "from-sky-400 to-indigo-500",
      accentClass: "bg-indigo-500",
    },
    {
      id: "tt-followers",
      label: "TikTok Followers Goal",
      current: currentTtFollowers,
      target: ttFollowersTarget,
      setTarget: setTtFollowersTarget,
      pct: ttFollowersPct,
      min: 50,
      max: 1000,
      step: 10,
      formatter: (val: number) => `${Math.round(val).toLocaleString()}`,
      color: "from-teal-400 to-emerald-500",
      accentClass: "bg-emerald-500",
    },
  ];

  return (
    <div
      id="goals-tracker"
      className="p-6 rounded-2xl border transition-all duration-300 mb-6 animate-fade-in-up
        dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 hover:shadow-md"
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center">
            <Target className="w-5 h-5 mr-2 text-indigo-500" />
            Interactive Target Goal Planner & Simulator
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Adjust the sliders to set and simulate new quarterly social media goals.
          </p>
        </div>
        <div className="p-2 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-500 dark:text-indigo-400 rounded-xl">
          <Award className="w-5 h-5" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {goalsList.map((g) => {
          const status = getStatusText(g.pct);
          return (
            <div
              key={g.id}
              className="p-4 rounded-xl border dark:border-slate-800 border-slate-100 dark:bg-slate-950/25 bg-slate-50/50 flex flex-col justify-between"
            >
              <div>
                <span className="text-xs font-semibold text-slate-400 dark:text-slate-500 block mb-1">
                  {g.label}
                </span>

                {/* Progress Circle & Text */}
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-2xl font-bold font-mono text-slate-800 dark:text-slate-100">
                    {g.formatter(g.current)}
                  </span>
                  <span className="text-xs text-slate-400">/</span>
                  <span className="text-sm font-semibold font-mono text-indigo-500 dark:text-indigo-400">
                    {g.formatter(g.target)}
                  </span>
                </div>

                {/* Slider */}
                <div className="mt-4 mb-4">
                  <input
                    type="range"
                    min={g.min}
                    max={g.max}
                    step={g.step}
                    value={g.target}
                    onChange={(e) => g.setTarget(parseFloat(e.target.value))}
                    className="w-full h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                    <span>Min: {g.formatter(g.min)}</span>
                    <span>Max: {g.formatter(g.max)}</span>
                  </div>
                </div>
              </div>

              {/* Progress gauge visualizer */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className={`${status.color}`}>{status.label}</span>
                  <span className="font-mono text-indigo-500 dark:text-indigo-400">{g.pct.toFixed(0)}%</span>
                </div>

                <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                  <div
                    style={{ width: `${g.pct}%` }}
                    className={`h-full rounded-full bg-gradient-to-r ${g.color} transition-all duration-300`}
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1.5">{status.desc}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Dynamic Summary Card */}
      <div className="mt-6 p-4 rounded-xl bg-indigo-500/5 border border-indigo-500/20 flex items-start gap-3">
        <Zap className="w-5 h-5 text-indigo-500 mt-0.5 flex-shrink-0" />
        <div>
          <span className="text-xs font-bold text-indigo-500 dark:text-indigo-400 block uppercase tracking-wider">
            SMM Growth Advisory & Recommendations
          </span>
          <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
            {igFollowersPct < 80
              ? "To accelerate your Instagram follower goal, scale your video content focusing on high-performing topics like the Dalton Highway and Chena Hot Springs. Double down on raw behind-the-scenes content; it drives a 24% higher engagement-to-follow conversion rate."
              : "Your Instagram community engagement is exceptional! It is time to diversify and allocate more ad spend and content creation hours towards high-reach TikTok campaigns. Focus on cross-promotions with clear Call-to-Actions (CTAs) directing to your tour booking system."}
          </p>
        </div>
      </div>
    </div>
  );
}
