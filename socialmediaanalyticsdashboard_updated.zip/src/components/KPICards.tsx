import { useState } from "react";
import { ArrowUpRight, ArrowDownRight, TrendingUp, Users, Target, DollarSign } from "lucide-react";
import { WeekData } from "../types";

interface KPICardsProps {
  currentWeek: WeekData;
  prevWeek?: WeekData;
  weeks: WeekData[];
  compareMode?: boolean;
  comparePrevPeriodWeeks?: WeekData[];
}

export default function KPICards({
  currentWeek,
  prevWeek,
  weeks,
  compareMode = false,
  comparePrevPeriodWeeks,
}: KPICardsProps) {
  const [hoveredKpi, setHoveredKpi] = useState<string | null>(null);

  const formatNum = (num: number) => Math.round(num).toLocaleString();
  const formatCurrency = (num: number) => `$${Math.round(num).toLocaleString()}`;

  const prevPeriodEndWeek = compareMode && comparePrevPeriodWeeks && comparePrevPeriodWeeks.length > 0
    ? comparePrevPeriodWeeks[comparePrevPeriodWeeks.length - 1]
    : undefined;

  // Cumulative KPIs: compare ending values
  const getCumulativeTrend = (curr: number, prev: number | undefined) => {
    if (prev === undefined || prev === 0) return null;
    const diff = curr - prev;
    const pct = (diff / prev) * 100;
    return {
      isUp: diff >= 0,
      text: `${diff >= 0 ? "+" : ""}${pct.toFixed(1)}%`,
      diff,
    };
  };

  // Incremental KPIs: sum values over the respective periods when compareMode is active
  const getIncrementalTrend = (
    currWeekVal: number,
    prevWeekVal: number | undefined,
    currentWeeksArray: WeekData[],
    prevWeeksArray: WeekData[] | undefined,
    metricKey: keyof WeekData
  ) => {
    if (compareMode && prevWeeksArray && prevWeeksArray.length > 0) {
      const currentSum = currentWeeksArray.reduce((sum, w) => sum + (Number(w[metricKey]) || 0), 0);
      const prevSum = prevWeeksArray.reduce((sum, w) => sum + (Number(w[metricKey]) || 0), 0);
      if (prevSum === 0) return null;
      const diff = currentSum - prevSum;
      const pct = (diff / prevSum) * 100;
      return {
        isUp: diff >= 0,
        text: `${diff >= 0 ? "+" : ""}${pct.toFixed(1)}%`,
        diff,
        isPeriodSum: true,
        currentSum,
        prevSum,
      };
    } else {
      if (prevWeekVal === undefined || prevWeekVal === 0) return null;
      const diff = currWeekVal - prevWeekVal;
      const pct = (diff / prevWeekVal) * 100;
      return {
        isUp: diff >= 0,
        text: `${diff >= 0 ? "+" : ""}${pct.toFixed(1)}%`,
        diff,
        isPeriodSum: false,
      };
    }
  };

  const igFollowersTrend = getCumulativeTrend(
    currentWeek.ig_followers,
    compareMode ? prevPeriodEndWeek?.ig_followers : prevWeek?.ig_followers
  );

  const ttFollowersTrend = getCumulativeTrend(
    currentWeek.tt_followers,
    compareMode ? prevPeriodEndWeek?.tt_followers : prevWeek?.tt_followers
  );

  const igReachTrend = getIncrementalTrend(
    currentWeek.ig_reach,
    prevWeek?.ig_reach,
    weeks,
    comparePrevPeriodWeeks,
    "ig_reach"
  );

  const gaRevenueTrend = getIncrementalTrend(
    currentWeek.ga_revenue,
    prevWeek?.ga_revenue,
    weeks,
    comparePrevPeriodWeeks,
    "ga_revenue"
  );

  const displayValue = (id: string, normalVal: string, trendObj: any) => {
    if (compareMode && trendObj && trendObj.isPeriodSum) {
      if (id === "ga-revenue") {
        return `$${Math.round(trendObj.currentSum).toLocaleString()}`;
      }
      return Math.round(trendObj.currentSum).toLocaleString();
    }
    return normalVal;
  };

  const kpis = [
    {
      id: "ig-followers",
      title: "Instagram Followers",
      value: formatNum(currentWeek.ig_followers),
      sub: compareMode ? "End of period total" : "Cumulative total",
      trend: igFollowersTrend,
      color: "from-pink-500 to-rose-500",
      textColor: "text-rose-500",
      bgColor: "bg-rose-500/10 dark:bg-rose-500/20",
      icon: Users,
      metricKey: "ig_followers" as keyof WeekData,
    },
    {
      id: "ig-reach",
      title: "Instagram Reach",
      value: displayValue("ig-reach", formatNum(currentWeek.ig_reach), igReachTrend),
      sub: compareMode ? "Sum of selected period" : "Accounts reached",
      trend: igReachTrend,
      color: "from-sky-400 to-indigo-500",
      textColor: "text-sky-500",
      bgColor: "bg-sky-500/10 dark:bg-sky-500/20",
      icon: Target,
      metricKey: "ig_reach" as keyof WeekData,
    },
    {
      id: "tt-followers",
      title: "TikTok Followers",
      value: formatNum(currentWeek.tt_followers),
      sub: compareMode ? "End of period total" : "Cumulative total",
      trend: ttFollowersTrend,
      color: "from-teal-400 to-emerald-500",
      textColor: "text-teal-500",
      bgColor: "bg-teal-500/10 dark:bg-teal-500/20",
      icon: TrendingUp,
      metricKey: "tt_followers" as keyof WeekData,
    },
    {
      id: "ga-revenue",
      title: "GA Revenue",
      value: displayValue("ga-revenue", formatCurrency(currentWeek.ga_revenue), gaRevenueTrend),
      sub: compareMode ? "Sum of selected period" : "Organic Traffic & CPC",
      trend: gaRevenueTrend,
      color: "from-emerald-400 to-emerald-600",
      textColor: "text-emerald-500",
      bgColor: "bg-emerald-500/10 dark:bg-emerald-500/20",
      icon: DollarSign,
      metricKey: "ga_revenue" as keyof WeekData,
    },
  ];

  const renderSparkline = (metricKey: keyof WeekData) => {
    // Find sequence of weeks ending with currentWeek
    const sorted = [...weeks].sort((a, b) => a.iso.localeCompare(b.iso));
    const currIdx = sorted.findIndex((w) => w.iso === currentWeek.iso);
    if (currIdx === -1) return null;

    // slice last 4 weeks ending with currentWeek
    const trendWeeks = sorted.slice(Math.max(0, currIdx - 3), currIdx + 1);
    if (trendWeeks.length < 2) {
      return (
        <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono italic block text-center mt-1">
          Not enough history
        </span>
      );
    }

    const values = trendWeeks.map((w) => Number(w[metricKey]) || 0);
    const minVal = Math.min(...values);
    const maxVal = Math.max(...values);
    const range = maxVal - minVal || 1;

    // SVG parameters (width=160, height=36)
    const width = 160;
    const height = 34;
    const padding = 3;
    const points = trendWeeks.map((w, index) => {
      const x = padding + (index * (width - padding * 2)) / (trendWeeks.length - 1);
      const y = height - padding - ((values[index] - minVal) / range) * (height - padding * 2);
      return { x, y, val: values[index] };
    });

    const dPath = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");

    return (
      <div className="flex flex-col items-center">
        <div className="flex items-center gap-3">
          <svg width={width} height={height} className="overflow-visible">
            {/* Area under line */}
            <path
              d={`${dPath} L ${points[points.length - 1].x} ${height} L ${points[0].x} ${height} Z`}
              fill="currentColor"
              className="text-indigo-500/15 dark:text-indigo-400/15"
            />
            {/* Main Sparkline Path */}
            <path
              d={dPath}
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-indigo-600 dark:text-indigo-400"
            />
            {/* Points */}
            {points.map((p, i) => (
              <circle
                key={i}
                cx={p.x}
                cy={p.y}
                r="2.5"
                fill="currentColor"
                className="text-indigo-700 dark:text-indigo-350"
              />
            ))}
          </svg>
          <div className="flex flex-col text-[8px] font-mono font-bold leading-tight text-slate-400 dark:text-slate-500">
            <span>Max: {metricKey === "ga_revenue" ? `$${Math.round(maxVal)}` : Math.round(maxVal).toLocaleString()}</span>
            <span>Min: {metricKey === "ga_revenue" ? `$${Math.round(minVal)}` : Math.round(minVal).toLocaleString()}</span>
          </div>
        </div>
        <div className="flex justify-between w-[160px] text-[8px] font-bold font-mono text-slate-400 dark:text-slate-500 mt-1">
          <span>{trendWeeks[0]?.iso}</span>
          <span>{trendWeeks[trendWeeks.length - 1]?.iso}</span>
        </div>
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {kpis.map((kpi) => {
        const Icon = kpi.icon;
        return (
          <div
            key={kpi.id}
            id={`kpi-card-${kpi.id}`}
            onMouseEnter={() => setHoveredKpi(kpi.id)}
            onMouseLeave={() => setHoveredKpi(null)}
            className="p-5 rounded-2xl transition-all duration-300 relative overflow-hidden group hover-glow animate-fade-in-up
              dark:bg-slate-900 dark:border-slate-800 dark:hover:border-slate-700 bg-white border border-slate-200 hover:shadow-lg"
          >
            {/* Top Indicator bar */}
            <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${kpi.color}`} />

            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  {kpi.title}
                </p>
                <h3 className="text-2xl font-bold font-mono tracking-tight text-slate-800 dark:text-slate-100 mt-1">
                  {kpi.value}
                </h3>
              </div>
              <div className={`p-2.5 rounded-xl ${kpi.bgColor} ${kpi.textColor}`}>
                <Icon className="w-5 h-5" />
              </div>
            </div>

            <div className="relative h-14 mt-3 border-t pt-2.5 dark:border-slate-800 border-slate-100 overflow-hidden">
              {/* Normal State Row */}
              <div
                className={`flex items-center justify-between text-xs transition-all duration-300 absolute inset-x-0 top-2.5 ${
                  hoveredKpi === kpi.id ? "-translate-y-12 opacity-0 pointer-events-none" : "translate-y-0 opacity-100"
                }`}
              >
                <span className="text-slate-400 dark:text-slate-500">{kpi.sub}</span>
                {kpi.trend ? (
                  <div className="flex flex-col items-end">
                    <span
                      className={`flex items-center font-semibold font-mono px-2 py-0.5 rounded-full text-[11px] ${
                        kpi.trend.isUp
                          ? "text-emerald-600 bg-emerald-50 dark:text-emerald-400 dark:bg-emerald-500/10"
                          : "text-rose-600 bg-rose-50 dark:text-rose-400 dark:bg-rose-500/10"
                      }`}
                    >
                      {kpi.trend.isUp ? (
                        <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />
                      ) : (
                        <ArrowDownRight className="w-3.5 h-3.5 mr-0.5" />
                      )}
                      {kpi.trend.text}
                    </span>
                    {compareMode && (
                      <span className="text-[9px] text-slate-400 mt-0.5 font-semibold font-mono">
                        vs. Prev. Period
                      </span>
                    )}
                  </div>
                ) : (
                  <span className="text-slate-400 dark:text-slate-500 font-mono">No prev. data</span>
                )}
              </div>

              {/* Hover Sparkline Chart */}
              <div
                className={`absolute inset-x-0 bottom-0.5 transition-all duration-300 transform ${
                  hoveredKpi === kpi.id ? "translate-y-0 opacity-100" : "translate-y-12 opacity-0 pointer-events-none"
                }`}
              >
                {renderSparkline(kpi.metricKey)}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
