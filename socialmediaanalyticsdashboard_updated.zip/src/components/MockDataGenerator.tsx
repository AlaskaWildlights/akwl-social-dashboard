import { useState } from "react";
import { WeekData } from "../types";
import { Plus, AlertCircle, Sparkles, TrendingUp, Zap, HelpCircle } from "lucide-react";

interface MockDataGeneratorProps {
  weeks: WeekData[];
  onAddWeek: (newWeek: WeekData) => void;
}

// Robust mathematical calculator for sequential weeks in English
function getWeekDateRangeString(year: number, week: number): string {
  const baseDate = new Date(2026, 3, 19); // April 19, 2026 (W17 start)
  const weekDiff = week - 17;
  const startDate = new Date(baseDate.getTime() + weekDiff * 7 * 24 * 60 * 60 * 1000);
  const endDate = new Date(startDate.getTime() + 6 * 24 * 60 * 60 * 1000);
  
  const optionsMonth = { month: "short" } as const;
  const startMonth = startDate.toLocaleDateString("en-US", optionsMonth);
  const endMonth = endDate.toLocaleDateString("en-US", optionsMonth);
  
  const startDay = startDate.getDate();
  const endDay = endDate.getDate();
  
  if (startMonth === endMonth) {
    return `${startMonth} ${startDay}–${endDay}`;
  } else {
    return `${startMonth} ${startDay}–${endMonth} ${endDay}`;
  }
}

export default function MockDataGenerator({ weeks, onAddWeek }: MockDataGeneratorProps) {
  const [campaignProfile, setCampaignProfile] = useState<"steady" | "viral" | "paid" | "low">("steady");
  const [customRevenue, setCustomRevenue] = useState(3000);

  const handleGenerate = () => {
    // Determine the next week ISO and label
    const sorted = [...weeks].sort((a, b) => a.iso.localeCompare(b.iso));
    const lastWeek = sorted[sorted.length - 1];
    let nextNum = 28;
    let nextYear = 2026;
    
    if (lastWeek) {
      const match = lastWeek.iso.match(/(\d{4})-W(\d+)/);
      if (match) {
        nextYear = parseInt(match[1]);
        nextNum = parseInt(match[2]) + 1;
        // Handle ISO week wrap around
        if (nextNum > 52) {
          nextNum = 1;
          nextYear += 1;
        }
      }
    }

    const nextIso = `${nextYear}-W${String(nextNum).padStart(2, "0")}`;
    const nextLabel = getWeekDateRangeString(nextYear, nextNum);

    const baseIGFollowers = lastWeek ? lastWeek.ig_followers : 721;
    const baseTTFollowers = lastWeek ? lastWeek.tt_followers : 251;

    // Default multipliers
    let multIG = 1.0;
    let multFB = 1.0;
    let multTT = 1.0;
    let multGA = 1.0;
    let autoRevenue = customRevenue;

    if (campaignProfile === "steady") {
      multIG = 1.05;
      multFB = 1.03;
      multTT = 1.08;
      multGA = 1.04;
    } else if (campaignProfile === "viral") {
      multIG = 2.8; // Massive viral IG spike
      multFB = 1.2;
      multTT = 2.2; // TikTok viral spillover
      multGA = 1.15;
      autoRevenue = Math.round(customRevenue * 1.3);
    } else if (campaignProfile === "paid") {
      multIG = 1.4;
      multFB = 1.3;
      multTT = 1.2;
      multGA = 3.2; // Huge Google Ads & PPC spike
      autoRevenue = Math.round(customRevenue * 3.5); // 3.5x revenue
    } else if (campaignProfile === "low") {
      multIG = 0.75;
      multFB = 0.8;
      multTT = 0.7;
      multGA = 0.65;
      autoRevenue = Math.round(customRevenue * 0.5);
    }

    // New Week construction with high-fidelity calculations
    const newWeek: WeekData = {
      iso: nextIso,
      label: nextLabel,
      ig_reach: Math.round((lastWeek ? lastWeek.ig_reach : 2600) * multIG * (0.9 + Math.random() * 0.2)),
      ig_views: Math.round((lastWeek ? lastWeek.ig_views : 6700) * multIG * (0.9 + Math.random() * 0.2)),
      ig_follows: Math.round((lastWeek ? lastWeek.ig_follows : 21) * multIG * (0.8 + Math.random() * 0.4)),
      ig_visits: Math.round((lastWeek ? lastWeek.ig_visits : 127) * multIG * (0.9 + Math.random() * 0.2)),
      ig_inter: Math.round((lastWeek ? lastWeek.ig_inter : 390) * multIG * (0.9 + Math.random() * 0.2)),
      ig_clicks: Math.round((lastWeek ? lastWeek.ig_clicks : 12) * multIG * (0.8 + Math.random() * 0.4)),
      ig_eng: parseFloat(Math.min(0.25, ((lastWeek ? lastWeek.ig_eng : 0.14) * (campaignProfile === "viral" ? 1.6 : campaignProfile === "low" ? 0.8 : 1.05) * (0.95 + Math.random() * 0.1))).toFixed(4)),
      ig_followers: Math.round(baseIGFollowers + (campaignProfile === "viral" ? 45 + Math.random() * 30 : campaignProfile === "steady" ? 10 + Math.random() * 10 : campaignProfile === "low" ? -2 : 5)),
      
      fb_views: Math.round((lastWeek ? lastWeek.fb_views : 2200) * multFB * (0.9 + Math.random() * 0.2)),
      fb_visits: Math.round((lastWeek ? lastWeek.fb_visits : 190) * multFB * (0.9 + Math.random() * 0.2)),
      fb_viewers: Math.round((lastWeek ? lastWeek.fb_viewers : 1200) * multFB * (0.9 + Math.random() * 0.2)),
      fb_follows: Math.round((lastWeek ? lastWeek.fb_follows : 5) * multFB + Math.random() * 3),
      fb_inter: Math.round((lastWeek ? lastWeek.fb_inter : 110) * multFB * (0.9 + Math.random() * 0.2)),
      fb_clicks: Math.round((lastWeek ? lastWeek.fb_clicks : 8) * multFB),

      tt_views: Math.round((lastWeek ? lastWeek.tt_views : 4000) * multTT * (0.9 + Math.random() * 0.2)),
      tt_reach: Math.round((lastWeek ? lastWeek.tt_reach : 3500) * multTT * (0.9 + Math.random() * 0.2)),
      tt_profile_views: Math.round((lastWeek ? lastWeek.tt_profile_views : 37) * multTT),
      tt_new_flw: Math.round((lastWeek ? lastWeek.tt_new_flw : 18) * multTT),
      tt_lost_flw: Math.round(Math.random() * 2),
      tt_net_growth: Math.round((lastWeek ? lastWeek.tt_net_growth : 18) * multTT),
      tt_likes: Math.round((lastWeek ? lastWeek.tt_likes : 250) * multTT * (0.9 + Math.random() * 0.2)),
      tt_comments: Math.round((lastWeek ? lastWeek.tt_comments : 10) * multTT),
      tt_shares: Math.round((lastWeek ? lastWeek.tt_shares : 17) * multTT),
      tt_website_clicks: Math.round((lastWeek ? lastWeek.tt_website_clicks : 2) * multTT),
      tt_followers: Math.round(baseTTFollowers + (campaignProfile === "viral" ? 55 + Math.random() * 25 : campaignProfile === "steady" ? 15 + Math.random() * 10 : campaignProfile === "low" ? -3 : 8)),
      
      tt_top_videos: campaignProfile === "viral" ? [
        {
          title: `🔥 VIRAL: Midnight Sun on Dalton Highway hits the algorithm! #alaska`,
          views: Math.round(25000 * (0.9 + Math.random() * 0.2)),
          likes: 2450,
          comments: 112,
          shares: 340,
          date: `2026/${String(nextNum > 26 ? 7 : 6).padStart(2, "0")}/${String((nextNum * 3) % 28 + 1).padStart(2, "0")}`
        }
      ] : [
        {
          title: `Spotting Moose on our Scenic Arctic Tour 🚐🌎 #explorefairbanks #travelalaska`,
          views: Math.round(950 * multTT * (0.8 + Math.random() * 0.4)),
          likes: Math.round(85 * multTT),
          comments: Math.round(4 * Math.random()),
          shares: Math.round(3 * Math.random()),
          date: `2026/${String(nextNum > 26 ? 7 : 6).padStart(2, "0")}/${String((nextNum * 3) % 28 + 1).padStart(2, "0")}`
        }
      ],

      ga_sessions: Math.round((lastWeek ? lastWeek.ga_sessions : 1600) * multGA * (0.9 + Math.random() * 0.2)),
      ga_eng_sessions: Math.round((lastWeek ? lastWeek.ga_eng_sessions : 750) * multGA * (0.9 + Math.random() * 0.2)),
      ga_eng_rate: parseFloat(Math.min(0.9, ((lastWeek ? lastWeek.ga_eng_rate : 0.46) * (0.95 + Math.random() * 0.1))).toFixed(4)),
      ga_avg_eng_time: parseFloat(((lastWeek ? lastWeek.ga_avg_eng_time : 35.2) * (0.9 + Math.random() * 0.2)).toFixed(1)),
      ga_key_events: Math.round((lastWeek ? lastWeek.ga_key_events : 21) * multGA + (campaignProfile === "paid" ? 35 : 5)),
      ga_revenue: autoRevenue,
      ga_sources: [
        { src: "google / organic", sessions: Math.round((lastWeek ? (lastWeek.ga_sessions * 0.4) : 600) * multGA), revenue: Math.round(autoRevenue * 0.6) },
        { src: "google / cpc", sessions: Math.round((lastWeek ? (lastWeek.ga_sessions * 0.3) : 450) * multGA), revenue: Math.round(autoRevenue * 0.3) },
        { src: "alaskawildlights.com / referral", sessions: Math.round((lastWeek ? (lastWeek.ga_sessions * 0.15) : 220) * multGA), revenue: Math.round(autoRevenue * 0.1) },
        { src: "direct / none", sessions: Math.round((lastWeek ? (lastWeek.ga_sessions * 0.15) : 220) * multGA), revenue: 0 }
      ],
      ga_missing: false
    };

    onAddWeek(newWeek);
  };

  return (
    <div
      id="mock-data-generator"
      className="p-6 rounded-2xl border transition-all duration-300 mb-6 animate-fade-in-up
        dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 hover:shadow-md"
    >
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2.5 bg-violet-100 dark:bg-violet-500/10 text-violet-600 dark:text-violet-400 rounded-xl">
          <Sparkles className="w-5 h-5" />
        </div>
        <div>
          <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100">
            SMM Weekly Scenario Simulator
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Simulate advanced campaigns, organic viral events, or seasonal drops to model ROI forecasts.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
            Campaign Scenario Profile
          </label>
          <select
            value={campaignProfile}
            onChange={(e) => setCampaignProfile(e.target.value as any)}
            className="w-full px-3 py-1.5 rounded-xl border text-xs text-slate-800 dark:text-slate-100 outline-none cursor-pointer
              dark:bg-slate-950 dark:border-slate-800 dark:focus:border-violet-500 focus:border-violet-500"
          >
            <option value="steady">Steady Growth Baseline</option>
            <option value="viral">Viral Organic Campaign (+Reels/TikTok)</option>
            <option value="paid">High PPC/Ad spend Campaign</option>
            <option value="low">Low Season Drop</option>
          </select>
        </div>

        <div>
          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
            Baseline GA Revenue Target
          </label>
          <div className="flex items-center gap-2">
            <span className="text-sm font-mono text-slate-400">$</span>
            <input
              type="number"
              value={customRevenue}
              onChange={(e) => setCustomRevenue(Math.max(0, parseInt(e.target.value) || 0))}
              className="flex-1 px-3 py-1.5 rounded-lg border font-mono text-xs text-slate-800 dark:text-slate-100 outline-none
                dark:bg-slate-950 dark:border-slate-800 dark:focus:border-violet-500 focus:border-violet-500"
            />
          </div>
        </div>

        <div className="flex items-end">
          <button
            onClick={handleGenerate}
            className="w-full py-2 px-4 rounded-xl font-bold text-xs bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white shadow-md hover:shadow-lg transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Simulate Next Week
          </button>
        </div>
      </div>

      <div className="flex items-start gap-2 p-3 rounded-lg dark:bg-slate-950/30 bg-slate-50/50 text-[11px] text-slate-400">
        <AlertCircle className="w-4 h-4 text-violet-500 flex-shrink-0 mt-0.5" />
        <p>
          Simulation profiles apply realistic SMM standard coefficients and mathematical trends directly into the state, immediately recalculating ROI, CPA, CTRs, and Goal thresholds.
        </p>
      </div>
    </div>
  );
}
