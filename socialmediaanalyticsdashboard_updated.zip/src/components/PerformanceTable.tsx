import { WeekData } from "../types";
import { Sparkles } from "lucide-react";

interface PerformanceTableProps {
  weeks: WeekData[];
}

export default function PerformanceTable({ weeks }: PerformanceTableProps) {
  // Sort weeks newest first
  const sortedWeeks = [...weeks].sort((a, b) => b.iso.localeCompare(a.iso));

  const formatNum = (num: number) => Math.round(num).toLocaleString();
  const formatPercent = (num: number) => `${(num * 100).toFixed(1)}%`;
  const formatCurrency = (num: number) => `$${Math.round(num).toLocaleString()}`;

  // Find min and max for each metric to calculate heatmap colors
  const getMinMax = (key: keyof WeekData) => {
    const values = weeks.map((w) => w[key] as number).filter((v) => typeof v === "number" && !isNaN(v));
    return {
      min: Math.min(...values),
      max: Math.max(...values),
    };
  };

  const limits = {
    ig_reach: getMinMax("ig_reach"),
    ig_views: getMinMax("ig_views"),
    ig_eng: getMinMax("ig_eng"),
    ig_followers: getMinMax("ig_followers"),
    fb_views: getMinMax("fb_views"),
    fb_inter: getMinMax("fb_inter"),
    tt_views: getMinMax("tt_views"),
    tt_followers: getMinMax("tt_followers"),
    ga_sessions: getMinMax("ga_sessions"),
    ga_revenue: getMinMax("ga_revenue"),
  };

  const getHeatmapStyle = (value: number, key: keyof typeof limits, platformColor: string) => {
    const { min, max } = limits[key];
    if (max === min) return {};
    const pct = (value - min) / (max - min);

    // Platform colors mapping (RGBA values)
    const colors: Record<string, string> = {
      ig: `rgba(236, 72, 153, ${pct * 0.15 + 0.02})`, // Pink
      fb: `rgba(59, 130, 246, ${pct * 0.15 + 0.02})`, // Blue
      tt: `rgba(20, 184, 166, ${pct * 0.15 + 0.02})`, // Teal
      ga: `rgba(16, 185, 129, ${pct * 0.15 + 0.02})`, // Emerald
    };

    return {
      backgroundColor: colors[platformColor],
      borderLeft: `2px solid ${value === max ? "#10b981" : "transparent"}`,
    };
  };

  return (
    <div
      id="performance-table-container"
      className="p-5 rounded-2xl border transition-all duration-300 animate-fade-in-up
        dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 hover:shadow-md"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-2">
        <div>
          <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center">
            <Sparkles className="w-4 h-4 mr-1.5 text-indigo-500" />
            Historical Performance Comparison Ledger
          </h4>
          <p className="text-[11px] text-slate-400">
            Relative performance heatmap based on historical peaks for each channel metric.
          </p>
        </div>
        <div className="flex items-center gap-2 text-[10px] text-slate-400">
          <span className="flex items-center">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 mr-1" />
            Max Peak
          </span>
        </div>
      </div>

      <div className="overflow-x-auto rounded-xl border dark:border-slate-800 border-slate-100">
        <table className="w-full border-collapse text-left text-xs font-sans">
          <thead>
            {/* Grouped Headers */}
            <tr className="border-b dark:border-slate-800 border-slate-100 bg-slate-50/50 dark:bg-slate-950/20 text-[10px] font-bold text-center">
              <th className="py-2 px-3 border-r dark:border-slate-800 border-slate-100 text-left">Period</th>
              <th colSpan={4} className="py-2 px-3 border-r dark:border-slate-800 border-slate-100 text-rose-500 bg-rose-500/5">Instagram</th>
              <th colSpan={2} className="py-2 px-3 border-r dark:border-slate-800 border-slate-100 text-blue-500 bg-blue-500/5">Facebook</th>
              <th colSpan={2} className="py-2 px-3 border-r dark:border-slate-800 border-slate-100 text-teal-400 bg-teal-500/5">TikTok</th>
              <th colSpan={2} className="py-2 px-3 text-emerald-500 bg-emerald-500/5">Acquisition (GA)</th>
            </tr>
            {/* Direct Metrics Headers */}
            <tr className="border-b dark:border-slate-800 border-slate-100 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
              <th className="py-2 px-3 border-r dark:border-slate-800 border-slate-100 font-sans">Week</th>
              <th className="py-2 px-3 text-right">Reach</th>
              <th className="py-2 px-3 text-right">Views</th>
              <th className="py-2 px-3 text-right">Eng%</th>
              <th className="py-2 px-3 border-r dark:border-slate-800 border-slate-100 text-right">Followers</th>
              <th className="py-2 px-3 text-right">Views</th>
              <th className="py-2 px-3 border-r dark:border-slate-800 border-slate-100 text-right">Inter.</th>
              <th className="py-2 px-3 text-right">Views</th>
              <th className="py-2 px-3 border-r dark:border-slate-800 border-slate-100 text-right">Followers</th>
              <th className="py-2 px-3 text-right">Sessions</th>
              <th className="py-2 px-3 text-right">Revenue</th>
            </tr>
          </thead>
          <tbody className="divide-y dark:divide-slate-800 divide-slate-100 font-mono text-[11px] text-slate-600 dark:text-slate-300">
            {sortedWeeks.map((row, idx) => {
              const isFirst = idx === 0;
              return (
                <tr
                  key={row.iso}
                  className={`transition-colors duration-150 hover:bg-slate-50 dark:hover:bg-slate-950/40 ${
                    isFirst ? "bg-indigo-500/5 font-semibold" : ""
                  }`}
                >
                  <td className="py-2.5 px-3 border-r dark:border-slate-800 border-slate-100 text-left font-sans flex items-center gap-1.5">
                    <span className="text-[10px] text-slate-400 dark:text-slate-500">{row.iso}</span>
                    <span className="truncate max-w-[100px]">{row.label}</span>
                  </td>
                  
                  {/* Instagram cells */}
                  <td className="py-2.5 px-3 text-right" style={getHeatmapStyle(row.ig_reach, "ig_reach", "ig")}>
                    {formatNum(row.ig_reach)}
                  </td>
                  <td className="py-2.5 px-3 text-right" style={getHeatmapStyle(row.ig_views, "ig_views", "ig")}>
                    {formatNum(row.ig_views)}
                  </td>
                  <td className="py-2.5 px-3 text-right" style={getHeatmapStyle(row.ig_eng, "ig_eng", "ig")}>
                    {formatPercent(row.ig_eng)}
                  </td>
                  <td className="py-2.5 px-3 border-r dark:border-slate-800 border-slate-100 text-right" style={getHeatmapStyle(row.ig_followers, "ig_followers", "ig")}>
                    {formatNum(row.ig_followers)}
                  </td>

                  {/* Facebook cells */}
                  <td className="py-2.5 px-3 text-right" style={getHeatmapStyle(row.fb_views, "fb_views", "fb")}>
                    {formatNum(row.fb_views)}
                  </td>
                  <td className="py-2.5 px-3 border-r dark:border-slate-800 border-slate-100 text-right" style={getHeatmapStyle(row.fb_inter, "fb_inter", "fb")}>
                    {formatNum(row.fb_inter)}
                  </td>

                  {/* TikTok cells */}
                  <td className="py-2.5 px-3 text-right" style={getHeatmapStyle(row.tt_views, "tt_views", "tt")}>
                    {formatNum(row.tt_views)}
                  </td>
                  <td className="py-2.5 px-3 border-r dark:border-slate-800 border-slate-100 text-right" style={getHeatmapStyle(row.tt_followers, "tt_followers", "tt")}>
                    {formatNum(row.tt_followers)}
                  </td>

                  {/* Acquisition cells */}
                  <td className="py-2.5 px-3 text-right" style={getHeatmapStyle(row.ga_sessions, "ga_sessions", "ga")}>
                    {formatNum(row.ga_sessions)}
                  </td>
                  <td className="py-2.5 px-3 text-right" style={getHeatmapStyle(row.ga_revenue, "ga_revenue", "ga")}>
                    {formatCurrency(row.ga_revenue)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
