import { useState } from "react";
import { WeekData } from "../types";
import { Check, Info, Shuffle } from "lucide-react";

interface PlatformComparisonProps {
  currentWeek: WeekData;
}

type Platform = "ig" | "fb" | "tt";

export default function PlatformComparison({ currentWeek }: PlatformComparisonProps) {
  const [platformA, setPlatformA] = useState<Platform>("ig");
  const [platformB, setPlatformB] = useState<Platform>("tt");

  const platformInfo = {
    ig: {
      name: "Instagram",
      color: "text-rose-500",
      bgColor: "bg-rose-500/10",
      borderColor: "border-rose-500",
      gradient: "from-pink-500 to-rose-500",
      followers: currentWeek.ig_followers,
      views: currentWeek.ig_views,
      reach: currentWeek.ig_reach,
      interactions: currentWeek.ig_inter,
      clicks: currentWeek.ig_clicks,
      engagement: currentWeek.ig_eng,
    },
    fb: {
      name: "Facebook",
      color: "text-sky-500",
      bgColor: "bg-sky-500/10",
      borderColor: "border-sky-500",
      gradient: "from-blue-500 to-sky-500",
      followers: 1200, // Estimated baseline
      views: currentWeek.fb_views,
      reach: currentWeek.fb_viewers, // FB viewers used as reach baseline
      interactions: currentWeek.fb_inter,
      clicks: currentWeek.fb_clicks,
      engagement: currentWeek.fb_views > 0 ? (currentWeek.fb_inter / currentWeek.fb_views) : 0,
    },
    tt: {
      name: "TikTok",
      color: "text-teal-400",
      bgColor: "bg-teal-500/10",
      borderColor: "border-teal-500",
      gradient: "from-teal-400 to-emerald-500",
      followers: currentWeek.tt_followers,
      views: currentWeek.tt_views,
      reach: currentWeek.tt_reach,
      interactions: currentWeek.tt_likes + currentWeek.tt_comments + currentWeek.tt_shares,
      clicks: currentWeek.tt_website_clicks,
      engagement: currentWeek.tt_views > 0 ? ((currentWeek.tt_likes + currentWeek.tt_comments + currentWeek.tt_shares) / currentWeek.tt_views) : 0,
    },
  };

  const handleSwap = () => {
    const temp = platformA;
    setPlatformA(platformB);
    setPlatformB(temp);
  };

  const dataA = platformInfo[platformA];
  const dataB = platformInfo[platformB];

  // Calculated metrics
  const getEfficiencyRatio = (interactions: number, reach: number) => {
    if (reach === 0) return 0;
    return (interactions / reach) * 100;
  };

  const getViralityScore = (views: number, followers: number) => {
    if (followers === 0) return 0;
    return views / followers;
  };

  const comparisonMetrics = [
    {
      label: "Community Followers",
      valA: dataA.followers,
      valB: dataB.followers,
      formatter: (val: number) => Math.round(val).toLocaleString(),
      desc: "Total size of the accumulated audience on the platform.",
    },
    {
      label: "Weekly Views / Impressions",
      valA: dataA.views,
      valB: dataB.views,
      formatter: (val: number) => Math.round(val).toLocaleString(),
      desc: "Total number of video views or feed impressions.",
    },
    {
      label: "Interactions Received",
      valA: dataA.interactions,
      valB: dataB.interactions,
      formatter: (val: number) => Math.round(val).toLocaleString(),
      desc: "Sum of likes, comments, shares, and saves.",
    },
    {
      label: "Engagement Rate (Engagement %)",
      valA: dataA.engagement * 100,
      valB: dataB.engagement * 100,
      formatter: (val: number) => `${val.toFixed(2)}%`,
      desc: "Percentage ratio between interactions and total views.",
    },
    {
      label: "Reach Efficiency (Interactions/Reach)",
      valA: getEfficiencyRatio(dataA.interactions, dataA.reach),
      valB: getEfficiencyRatio(dataB.interactions, dataB.reach),
      formatter: (val: number) => `${val.toFixed(2)}%`,
      desc: "Percentage of reached users who decide to actively interact with the content.",
    },
    {
      label: "Virality Factor (Views/Followers)",
      valA: getViralityScore(dataA.views, dataA.followers),
      valB: getViralityScore(dataB.views, dataB.followers),
      formatter: (val: number) => `${val.toFixed(1)}x`,
      desc: "How many times your views exceed your current follower base. High values indicate strong external algorithmic reach.",
    },
    {
      label: "Link Clicks (Bio/Website Clicks)",
      valA: dataA.clicks,
      valB: dataB.clicks,
      formatter: (val: number) => Math.round(val).toLocaleString(),
      desc: "Clicks redirected to your corporate website or link-in-bio.",
    },
  ];

  return (
    <div
      id="platform-comparison"
      className="p-6 rounded-2xl border transition-all duration-300 mb-6 animate-fade-in-up
        dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 hover:shadow-md"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
        <div>
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center">
            <Shuffle className="w-5 h-5 mr-2 text-indigo-500" />
            Detailed Platform Comparison
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Interactively compare content efficiency, reach, and virality across social channels.
          </p>
        </div>

        {/* Dynamic Platform Selectors */}
        <div className="flex items-center gap-2 self-start md:self-auto">
          <select
            value={platformA}
            onChange={(e) => setPlatformA(e.target.value as Platform)}
            className="px-3 py-1.5 rounded-xl border font-semibold text-xs outline-none cursor-pointer transition-all duration-300
              dark:bg-slate-950 dark:border-slate-800 dark:text-slate-200 dark:hover:border-slate-700
              bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"
          >
            <option value="ig" disabled={platformB === "ig"}>Instagram</option>
            <option value="fb" disabled={platformB === "fb"}>Facebook</option>
            <option value="tt" disabled={platformB === "tt"}>TikTok</option>
          </select>

          <button
            onClick={handleSwap}
            className="p-1.5 rounded-lg border transition-all duration-300 dark:border-slate-800 dark:bg-slate-950 dark:hover:bg-slate-900 border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-500 cursor-pointer"
            title="Swap platforms"
          >
            <Shuffle className="w-4 h-4 rotate-90" />
          </button>

          <select
            value={platformB}
            onChange={(e) => setPlatformB(e.target.value as Platform)}
            className="px-3 py-1.5 rounded-xl border font-semibold text-xs outline-none cursor-pointer transition-all duration-300
              dark:bg-slate-950 dark:border-slate-800 dark:text-slate-200 dark:hover:border-slate-700
              bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"
          >
            <option value="ig" disabled={platformA === "ig"}>Instagram</option>
            <option value="fb" disabled={platformA === "fb"}>Facebook</option>
            <option value="tt" disabled={platformA === "tt"}>TikTok</option>
          </select>
        </div>
      </div>

      {/* Visual head-to-head header */}
      <div className="grid grid-cols-3 gap-4 mb-6 text-center border-b pb-4 dark:border-slate-800 border-slate-100">
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/40">
          <span className={`text-sm font-bold block ${dataA.color}`}>{dataA.name}</span>
          <span className="text-xs font-mono text-slate-400 mt-1 block">Channel A</span>
        </div>
        <div className="flex items-center justify-center font-mono text-xs font-bold text-slate-400">VS</div>
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/40">
          <span className={`text-sm font-bold block ${dataB.color}`}>{dataB.name}</span>
          <span className="text-xs font-mono text-slate-400 mt-1 block">Channel B</span>
        </div>
      </div>

      {/* Comparison list */}
      <div className="space-y-4">
        {comparisonMetrics.map((metric, idx) => {
          const isWinnerA = metric.valA > metric.valB;
          const isWinnerB = metric.valB > metric.valA;

          // Performance ratio for progress bar
          const total = metric.valA + metric.valB;
          const pctA = total > 0 ? (metric.valA / total) * 100 : 50;
          const pctB = total > 0 ? (metric.valB / total) * 100 : 50;

          return (
            <div key={idx} className="group/item">
              <div className="flex justify-between items-center text-xs font-semibold mb-1 text-slate-700 dark:text-slate-300">
                <span className="flex items-center group-hover/item:text-indigo-500 transition-colors">
                  {metric.label}
                  <div className="relative ml-1 group/tooltip">
                    <Info className="w-3 h-3 text-slate-400 cursor-help" />
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 rounded bg-slate-950 text-white text-[10px] leading-relaxed hidden group-hover/tooltip:block z-10 shadow-xl pointer-events-none border border-slate-800">
                      {metric.desc}
                    </div>
                  </div>
                </span>

                <div className="flex items-center gap-4 font-mono text-[11px]">
                  <span className={`${isWinnerA ? "text-emerald-500 font-bold" : "text-slate-400"}`}>
                    {metric.formatter(metric.valA)}
                  </span>
                  <span className="text-slate-300 dark:text-slate-700">|</span>
                  <span className={`${isWinnerB ? "text-emerald-500 font-bold" : "text-slate-400"}`}>
                    {metric.formatter(metric.valB)}
                  </span>
                </div>
              </div>

              {/* Head-to-Head Progress Split */}
              <div className="h-2 rounded-full overflow-hidden bg-slate-100 dark:bg-slate-800 flex">
                <div
                  style={{ width: `${pctA}%` }}
                  className={`h-full bg-gradient-to-r ${dataA.gradient} rounded-l-full transition-all duration-500`}
                />
                <div
                  style={{ width: `${pctB}%` }}
                  className={`h-full bg-gradient-to-r ${dataB.gradient} rounded-r-full transition-all duration-500`}
                />
              </div>

              {/* Helper tags under bar */}
              <div className="flex justify-between text-[10px] text-slate-400 dark:text-slate-500 mt-1">
                <span className="flex items-center min-w-[50px]">
                  {isWinnerA && <Check className="w-3 h-3 text-emerald-500 mr-0.5" />}
                  {isWinnerA ? "Leader" : ""}
                </span>
                <span className="text-center font-mono text-[9px]">
                  {pctA.toFixed(0)}% / {pctB.toFixed(0)}%
                </span>
                <span className="flex items-center justify-end min-w-[50px]">
                  {isWinnerB && <Check className="w-3 h-3 text-emerald-500 mr-0.5" />}
                  {isWinnerB ? "Leader" : ""}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
