import { useState } from "react";
import { WeekData } from "../types";
import { Calculator, DollarSign, TrendingUp, Target, ArrowRight, HelpCircle } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

interface SMMRoiModelerProps {
  filteredWeeks: WeekData[];
  weeklyBudget: number;
  setWeeklyBudget: (budget: number) => void;
}

export default function SMMRoiModeler({ filteredWeeks, weeklyBudget, setWeeklyBudget }: SMMRoiModelerProps) {
  const numWeeks = filteredWeeks.length || 1;
  const totalSpend = numWeeks * weeklyBudget;
  
  // Summing metrics across active period
  const totalRevenue = filteredWeeks.reduce((sum, w) => sum + w.ga_revenue, 0);
  const totalKeyEvents = filteredWeeks.reduce((sum, w) => sum + w.ga_key_events, 0) || 1;
  const totalSessions = filteredWeeks.reduce((sum, w) => sum + w.ga_sessions, 0) || 1;

  // Multi-platform click sums for CTR
  const totalIgClicks = filteredWeeks.reduce((sum, w) => sum + w.ig_clicks, 0);
  const totalIgViews = filteredWeeks.reduce((sum, w) => sum + w.ig_views, 0) || 1;
  
  const totalFbClicks = filteredWeeks.reduce((sum, w) => sum + w.fb_clicks, 0);
  const totalFbViews = filteredWeeks.reduce((sum, w) => sum + w.fb_views, 0) || 1;

  const totalTtClicks = filteredWeeks.reduce((sum, w) => sum + w.tt_website_clicks, 0);
  const totalTtViews = filteredWeeks.reduce((sum, w) => sum + (w.tt_views || 0), 0) || 1;

  // Calculators
  const cpa = totalSpend / totalKeyEvents;
  const roi = ((totalRevenue - totalSpend) / totalSpend) * 100;
  
  const igCtr = (totalIgClicks / totalIgViews) * 100;
  const fbCtr = (totalFbClicks / totalFbViews) * 100;
  const ttCtr = (totalTtClicks / totalTtViews) * 100;

  // Format Helpers
  const formatCurrency = (val: number) => `$${Math.round(val).toLocaleString()}`;
  const formatDecCurrency = (val: number) => `$${val.toFixed(2)}`;

  // Prep Recharts data for weekly CTR tracking
  const weeklyCtrData = filteredWeeks.map((w) => {
    const igV = w.ig_views || 1;
    const fbV = w.fb_views || 1;
    const ttV = w.tt_views || 1;

    return {
      week: w.iso,
      label: w.label,
      "IG CTR %": parseFloat(((w.ig_clicks / igV) * 100).toFixed(3)),
      "FB CTR %": parseFloat(((w.fb_clicks / fbV) * 100).toFixed(3)),
      "TikTok CTR %": parseFloat((((w.tt_website_clicks || 0) / ttV) * 100).toFixed(3)),
    };
  });

  return (
    <div
      id="smm-roi-modeler"
      className="p-6 rounded-2xl border transition-all duration-300 animate-fade-in-up
        dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 hover:shadow-md"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
        <div>
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center">
            <Calculator className="w-5 h-5 mr-2 text-indigo-500" />
            Executive Paid Ads ROI & Acquisition Modeler
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Simulate and evaluate campaign budgets, ROI performance, and real click-through conversions.
          </p>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-500 dark:text-indigo-400 rounded-lg text-xs font-bold">
          <span>Active Period: {numWeeks} {numWeeks === 1 ? "Week" : "Weeks"}</span>
        </div>
      </div>

      {/* Interactive Budget Modeler Control Slider */}
      <div className="p-4 rounded-xl dark:bg-slate-950/40 bg-slate-50 border dark:border-slate-800 border-slate-100 mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
            Set Simulated Weekly Ad Budget (Meta & Google Ads)
          </span>
          <span className="text-sm font-extrabold font-mono text-indigo-600 dark:text-indigo-400">
            {formatCurrency(weeklyBudget)} / week
          </span>
        </div>
        <input
          type="range"
          min={100}
          max={5000}
          step={50}
          value={weeklyBudget}
          onChange={(e) => setWeeklyBudget(parseInt(e.target.value))}
          className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
        />
        <div className="flex justify-between text-[10px] text-slate-400 mt-1.5">
          <span>Min Campaign: $100/wk</span>
          <span>Max Enterprise Campaign: $5,000/wk</span>
        </div>
      </div>

      {/* Grid of SMM ROI KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {/* Total Spend Card */}
        <div className="p-4 rounded-xl border dark:border-slate-800 border-slate-150 dark:bg-slate-950/20 bg-white">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center">
            <DollarSign className="w-3.5 h-3.5 mr-1 text-slate-400" />
            Total Ad Spend
          </span>
          <h4 className="text-xl font-bold font-mono text-slate-800 dark:text-slate-100 mt-2">
            {formatCurrency(totalSpend)}
          </h4>
          <span className="text-[10px] text-slate-400 mt-1 block">
            Across {numWeeks} weeks active
          </span>
        </div>

        {/* Total Conversions / Key Events */}
        <div className="p-4 rounded-xl border dark:border-slate-800 border-slate-150 dark:bg-slate-950/20 bg-white">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center">
            <Target className="w-3.5 h-3.5 mr-1 text-indigo-500" />
            GA Key Events
          </span>
          <h4 className="text-xl font-bold font-mono text-slate-800 dark:text-slate-100 mt-2">
            {totalKeyEvents}
          </h4>
          <span className="text-[10px] text-slate-400 mt-1 block">
            {(totalKeyEvents / totalSessions * 100).toFixed(2)}% session conversion rate
          </span>
        </div>

        {/* Cost Per Acquisition (CPA) */}
        <div className="p-4 rounded-xl border dark:border-slate-800 border-slate-150 dark:bg-slate-950/20 bg-white">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center">
            <Target className="w-3.5 h-3.5 mr-1 text-emerald-500" />
            CPA (Cost per Acquisition)
          </span>
          <h4 className="text-xl font-bold font-mono text-slate-800 dark:text-slate-100 mt-2">
            {formatDecCurrency(cpa)}
          </h4>
          <span className={`text-[10px] font-bold mt-1 inline-block px-1.5 py-0.5 rounded ${
            cpa < 25 ? "bg-emerald-500/10 text-emerald-500" : cpa < 50 ? "bg-amber-500/10 text-amber-500" : "bg-rose-500/10 text-rose-500"
          }`}>
            {cpa < 25 ? "Excellent Efficiency" : cpa < 50 ? "Healthy Margin" : "High Acquisition Cost"}
          </span>
        </div>

        {/* Return on Investment (ROI) */}
        <div className="p-4 rounded-xl border dark:border-slate-800 border-slate-150 dark:bg-slate-950/20 bg-white">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center">
            <TrendingUp className="w-3.5 h-3.5 mr-1 text-pink-500" />
            Campaign ROI
          </span>
          <h4 className={`text-xl font-bold font-mono mt-2 ${roi >= 0 ? "text-emerald-500" : "text-rose-500"}`}>
            {roi >= 0 ? "+" : ""}{roi.toFixed(1)}%
          </h4>
          <span className="text-[10px] text-slate-400 mt-1 block">
            Net return on ad investment
          </span>
        </div>
      </div>

      {/* Multi-platform Cumulative Click-Through Rates (CTR %) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 text-xs">
        <div className="p-4 rounded-xl bg-rose-500/5 border border-rose-500/10 flex items-center justify-between">
          <div>
            <span className="text-slate-400 block font-semibold">Instagram CTR</span>
            <span className="text-lg font-bold font-mono text-rose-500 mt-1 block">{igCtr.toFixed(3)}%</span>
          </div>
          <span className="text-[10px] font-mono text-slate-400">{totalIgClicks} clicks</span>
        </div>

        <div className="p-4 rounded-xl bg-sky-500/5 border border-sky-500/10 flex items-center justify-between">
          <div>
            <span className="text-slate-400 block font-semibold">Facebook CTR</span>
            <span className="text-lg font-bold font-mono text-sky-500 mt-1 block">{fbCtr.toFixed(3)}%</span>
          </div>
          <span className="text-[10px] font-mono text-slate-400">{totalFbClicks} clicks</span>
        </div>

        <div className="p-4 rounded-xl bg-teal-500/5 border border-teal-500/10 flex items-center justify-between">
          <div>
            <span className="text-slate-400 block font-semibold">TikTok CTR</span>
            <span className="text-lg font-bold font-mono text-teal-400 mt-1 block">{ttCtr.toFixed(3)}%</span>
          </div>
          <span className="text-[10px] font-mono text-slate-400">{totalTtClicks} clicks</span>
        </div>
      </div>

      {/* Recharts chart showing CTR values over all weeks */}
      <div>
        <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-4 uppercase tracking-wider">
          Weekly Comparative Click-Through Rate (CTR %) Trend
        </h4>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={weeklyCtrData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="week" stroke="#94a3b8" fontSize={9} />
              <YAxis stroke="#94a3b8" fontSize={9} tickFormatter={(v) => `${v}%`} />
              <Tooltip formatter={(value: any) => `${value}%`} />
              <Legend iconType="circle" />
              <Bar name="Instagram CTR %" dataKey="IG CTR %" fill="#ec4899" radius={[3, 3, 0, 0]} label={{ fill: '#64748b', fontSize: 9, position: 'top' }} />
              <Bar name="Facebook CTR %" dataKey="FB CTR %" fill="#3b82f6" radius={[3, 3, 0, 0]} label={{ fill: '#64748b', fontSize: 9, position: 'top' }} />
              <Bar name="TikTok CTR %" dataKey="TikTok CTR %" fill="#14b8a6" radius={[3, 3, 0, 0]} label={{ fill: '#64748b', fontSize: 9, position: 'top' }} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
