import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { WeekData } from "../types";
import { TrendingUp, DollarSign, Award, ArrowUpRight } from "lucide-react";

interface SpendCorrelationChartProps {
  filteredWeeks: WeekData[];
  weeklyBudget: number;
}

export default function SpendCorrelationChart({ filteredWeeks, weeklyBudget }: SpendCorrelationChartProps) {
  // Calculate platform allocation and growth for each week
  const scatterData = filteredWeeks.map((w) => {
    const igClicks = w.ig_clicks || 1;
    const fbClicks = w.fb_clicks || 1;
    const ttClicks = w.tt_website_clicks || 1;
    const totalClicks = igClicks + fbClicks + ttClicks;

    // Distribute budget: 40% base + 60% performance-based (clicks)
    const igSpend = weeklyBudget * (0.45 * 0.4 + 0.6 * (igClicks / totalClicks));
    const fbSpend = weeklyBudget * (0.20 * 0.4 + 0.6 * (fbClicks / totalClicks));
    const ttSpend = weeklyBudget * (0.35 * 0.4 + 0.6 * (ttClicks / totalClicks));

    return {
      week: w.iso,
      label: w.label,
      igSpend: Math.round(igSpend),
      fbSpend: Math.round(fbSpend),
      ttSpend: Math.round(ttSpend),
      igGrowth: w.ig_follows || 0,
      fbGrowth: w.fb_follows || 0,
      ttGrowth: w.tt_net_growth || 0,
    };
  });

  // Prepare platform-specific arrays for Scatter plots
  const igPoints = scatterData.map((d) => ({
    week: d.week,
    label: d.label,
    platform: "Instagram",
    spend: d.igSpend,
    growth: d.igGrowth,
  }));

  const fbPoints = scatterData.map((d) => ({
    week: d.week,
    label: d.label,
    platform: "Facebook",
    spend: d.fbSpend,
    growth: d.fbGrowth,
  }));

  const ttPoints = scatterData.map((d) => ({
    week: d.week,
    label: d.label,
    platform: "TikTok",
    spend: d.ttSpend,
    growth: d.ttGrowth,
  }));

  // Aggregated platform ROI metrics
  const totalIgSpend = scatterData.reduce((sum, d) => sum + d.igSpend, 0);
  const totalIgGrowth = scatterData.reduce((sum, d) => sum + d.igGrowth, 0);

  const totalFbSpend = scatterData.reduce((sum, d) => sum + d.fbSpend, 0);
  const totalFbGrowth = scatterData.reduce((sum, d) => sum + d.fbGrowth, 0);

  const totalTtSpend = scatterData.reduce((sum, d) => sum + d.ttSpend, 0);
  const totalTtGrowth = scatterData.reduce((sum, d) => sum + d.ttGrowth, 0);

  // Growth per $100 spent (ROI efficiency index)
  const igRoiIndex = totalIgSpend > 0 ? (totalIgGrowth / totalIgSpend) * 100 : 0;
  const fbRoiIndex = totalFbSpend > 0 ? (totalFbGrowth / totalFbSpend) * 100 : 0;
  const ttRoiIndex = totalTtSpend > 0 ? (totalTtGrowth / totalTtSpend) * 100 : 0;

  // Find the winning platform
  const roiScores = [
    { name: "Instagram", score: igRoiIndex, color: "text-pink-500", bgColor: "bg-pink-500/10" },
    { name: "Facebook", score: fbRoiIndex, color: "text-blue-500", bgColor: "bg-blue-500/10" },
    { name: "TikTok", score: ttRoiIndex, color: "text-teal-500", bgColor: "bg-teal-500/10" },
  ];
  roiScores.sort((a, b) => b.score - a.score);
  const winner = roiScores[0];

  const formatCurrency = (val: number) => `$${Math.round(val).toLocaleString()}`;

  // Custom tooltips for ScatterChart
  const CustomScatterTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 border border-slate-800 text-white p-3 rounded-xl shadow-xl text-xs font-sans space-y-1">
          <p className="font-bold text-slate-300">Week: {data.week} ({data.label})</p>
          <div className="flex items-center gap-2 mt-1">
            <span className={`w-2 h-2 rounded-full ${
              data.platform === "Instagram" ? "bg-pink-500" : data.platform === "Facebook" ? "bg-blue-500" : "bg-teal-400"
            }`} />
            <p className="font-semibold text-white">{data.platform}</p>
          </div>
          <div className="border-t border-slate-800/80 mt-1.5 pt-1.5 space-y-0.5 font-mono text-slate-400">
            <p>Allocated Spend: <span className="text-white font-bold">{formatCurrency(data.spend)}</span></p>
            <p>Follower Growth: <span className="text-white font-bold">+{data.growth.toLocaleString()}</span></p>
            <p>Efficiency: <span className="text-emerald-400 font-bold">{(data.growth / (data.spend || 1) * 100).toFixed(1)} flw/$100</span></p>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="p-6 rounded-2xl border transition-all duration-300 dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 hover:shadow-md">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
        <div>
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center">
            <TrendingUp className="w-5 h-5 mr-2 text-indigo-500" />
            Ad Spend vs. Follower Growth Correlation Chart
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Analyze the relationship between weekly platform budgets and customer acquisition efficiency to identify top ROI performers.
          </p>
        </div>

        {/* Dynamic ROI Winner Badge */}
        {winner.score > 0 && (
          <div className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full ${winner.bgColor} ${winner.color} border border-current/10 text-xs font-bold animate-pulse`}>
            <Award className="w-4 h-4" />
            <span>Best Follower ROI: {winner.name}</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Scatter Correlation Plot */}
        <div className="lg:col-span-2 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis
                type="number"
                dataKey="spend"
                name="Marketing Spend"
                unit=" USD"
                stroke="#94a3b8"
                fontSize={9}
                tickFormatter={(v) => `$${v}`}
              />
              <YAxis
                type="number"
                dataKey="growth"
                name="Followers Gained"
                unit=" flw"
                stroke="#94a3b8"
                fontSize={9}
              />
              <Tooltip content={<CustomScatterTooltip />} />
              <Legend verticalAlign="top" height={36} iconType="circle" />
              <Scatter name="Instagram" data={igPoints} fill="#ec4899" shape="circle" lineJointType="monotone" />
              <Scatter name="Facebook" data={fbPoints} fill="#3b82f6" shape="circle" />
              <Scatter name="TikTok" data={ttPoints} fill="#14b8a6" shape="circle" />
            </ScatterChart>
          </ResponsiveContainer>
        </div>

        {/* Platform ROI Summary */}
        <div className="space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase text-slate-400 dark:text-slate-500 tracking-wider">
              Acquisition Efficiency Index
            </h4>
            
            <div className="space-y-2.5">
              {/* Instagram ROI */}
              <div className="p-3 rounded-xl border dark:border-slate-800 border-slate-100 dark:bg-slate-950/20 bg-slate-50/50">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-pink-500">Instagram SMM</span>
                  <span className="text-[10px] text-slate-400">Spend: {formatCurrency(totalIgSpend)}</span>
                </div>
                <div className="flex justify-between items-baseline mt-1.5">
                  <span className="text-base font-bold font-mono text-slate-800 dark:text-slate-100">
                    {igRoiIndex.toFixed(1)} <span className="text-xs font-medium text-slate-400">flw/$100</span>
                  </span>
                  <span className="text-xs font-mono text-slate-500">+{totalIgGrowth.toLocaleString()} total</span>
                </div>
              </div>

              {/* Facebook ROI */}
              <div className="p-3 rounded-xl border dark:border-slate-800 border-slate-100 dark:bg-slate-950/20 bg-slate-50/50">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-blue-500">Facebook SMM</span>
                  <span className="text-[10px] text-slate-400">Spend: {formatCurrency(totalFbSpend)}</span>
                </div>
                <div className="flex justify-between items-baseline mt-1.5">
                  <span className="text-base font-bold font-mono text-slate-800 dark:text-slate-100">
                    {fbRoiIndex.toFixed(1)} <span className="text-xs font-medium text-slate-400">flw/$100</span>
                  </span>
                  <span className="text-xs font-mono text-slate-500">+{totalFbGrowth.toLocaleString()} total</span>
                </div>
              </div>

              {/* TikTok ROI */}
              <div className="p-3 rounded-xl border dark:border-slate-800 border-slate-100 dark:bg-slate-950/20 bg-slate-50/50">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-teal-500">TikTok SMM</span>
                  <span className="text-[10px] text-slate-400">Spend: {formatCurrency(totalTtSpend)}</span>
                </div>
                <div className="flex justify-between items-baseline mt-1.5">
                  <span className="text-base font-bold font-mono text-slate-800 dark:text-slate-100">
                    {ttRoiIndex.toFixed(1)} <span className="text-xs font-medium text-slate-400">flw/$100</span>
                  </span>
                  <span className="text-xs font-mono text-slate-500">+{totalTtGrowth.toLocaleString()} total</span>
                </div>
              </div>
            </div>
          </div>

          <div className="text-[10px] text-slate-400 dark:text-slate-500 leading-relaxed bg-slate-100/50 dark:bg-slate-950/40 p-2.5 rounded-xl border dark:border-slate-850 border-slate-150">
            <div className="flex gap-1.5 text-indigo-500 dark:text-indigo-400 font-bold mb-0.5">
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>Marketing Insight</span>
            </div>
            <span>Platform spends correlate directly to audience CTR & clicks. Higher click-throughs automatically pull in more followers, creating dynamic clusters above.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
