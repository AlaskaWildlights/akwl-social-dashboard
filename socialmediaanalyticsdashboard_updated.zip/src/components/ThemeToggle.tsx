import { Sun, Moon } from "lucide-react";

interface ThemeToggleProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
}

export default function ThemeToggle({ darkMode, setDarkMode }: ThemeToggleProps) {
  return (
    <button
      id="theme-toggle"
      onClick={() => setDarkMode(!darkMode)}
      className="p-2 rounded-xl border transition-all duration-300 cursor-pointer flex items-center justify-center
        dark:border-slate-800 dark:bg-slate-900 dark:text-amber-400 dark:hover:bg-slate-800 dark:hover:border-slate-700
        border-slate-200 bg-white text-indigo-600 hover:bg-slate-50 hover:border-slate-300"
      title={darkMode ? "Activar modo claro" : "Activar modo oscuro"}
    >
      {darkMode ? (
        <Sun className="w-5 h-5 transition-transform duration-500 hover:rotate-45" id="sun-icon" />
      ) : (
        <Moon className="w-5 h-5 transition-transform duration-500 hover:-rotate-12" id="moon-icon" />
      )}
    </button>
  );
}
