import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from "recharts";
import { GASource } from "../types";
import { Compass, CircleDollarSign } from "lucide-react";

interface TrafficSourceChartProps {
  sources: GASource[];
}

const COLORS = ["#6366f1", "#06b6d4", "#10b981", "#f59e0b", "#ec4899", "#8b5cf6"];

export default function TrafficSourceChart({ sources }: TrafficSourceChartProps) {
  // Sort and filter top sources
  const sortedSources = [...sources]
    .sort((a, b) => b.sessions - a.sessions)
    .filter((s) => s.src && s.src.trim().length > 0);

  const topSourcesData = sortedSources.slice(0, 6);
  const otherSourcesSum = sortedSources.slice(6).reduce((acc, curr) => acc + curr.sessions, 0);
  const otherRevenueSum = sortedSources.slice(6).reduce((acc, curr) => acc + curr.revenue, 0);

  const chartData = [...topSourcesData];
  if (otherSourcesSum > 0) {
    chartData.push({
      src: "Others",
      sessions: otherSourcesSum,
      revenue: otherRevenueSum,
    });
  }

  const formatValue = (value: number) => Math.round(value).toLocaleString();
  const formatCurrency = (value: number) => `$${Math.round(value).toLocaleString()}`;

  // Custom tooltips for clean UI
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg shadow-xl font-sans text-xs">
          <p className="font-bold text-slate-200">{data.src || data.name}</p>
          <p className="text-indigo-400 mt-1">Sessions: {formatValue(data.sessions)}</p>
          {data.revenue > 0 && (
            <p className="text-emerald-400 font-semibold mt-0.5">
              Revenue: {formatCurrency(data.revenue)}
            </p>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div
      id="traffic-source-chart"
      className="p-5 rounded-2xl border transition-all duration-300 animate-fade-in-up
        dark:bg-slate-900 dark:border-slate-800 bg-white border-slate-200 hover:shadow-md"
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center">
            <Compass className="w-4.5 h-4.5 mr-1.5 text-indigo-500" />
            Google Analytics Traffic Channels
          </h4>
          <p className="text-[11px] text-slate-400">Channel traffic distribution and conversion revenue acquisition.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-center">
        {/* Recharts Pie Chart */}
        <div className="h-56 relative">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={4}
                dataKey="sessions"
                nameKey="src"
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none">
            <span className="text-[10px] text-slate-400 block uppercase font-semibold">Sessions</span>
            <span className="text-xl font-bold text-slate-700 dark:text-slate-200 font-mono">
              {formatValue(sources.reduce((sum, s) => sum + s.sessions, 0))}
            </span>
          </div>
        </div>

        {/* Legend / Metrics list */}
        <div className="space-y-2.5">
          {chartData.map((source, index) => {
            const pct = (source.sessions / sources.reduce((sum, s) => sum + s.sessions, 0)) * 100;
            return (
              <div
                key={source.src}
                className="flex items-center justify-between p-2 rounded-xl dark:bg-slate-950/40 bg-slate-50/50 hover:bg-slate-50 border border-transparent dark:hover:border-slate-800 hover:border-slate-100 transition-all text-xs"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span
                    className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  />
                  <span className="font-semibold text-slate-700 dark:text-slate-300 truncate">
                    {source.src}
                  </span>
                </div>
                <div className="flex items-center gap-3 font-mono text-[11px] flex-shrink-0">
                  <span className="text-slate-400">{pct.toFixed(1)}%</span>
                  <span className="font-bold text-slate-600 dark:text-slate-300">
                    {formatValue(source.sessions)}
                  </span>
                  {source.revenue > 0 && (
                    <span className="text-emerald-500 font-bold flex items-center">
                      <CircleDollarSign className="w-3.5 h-3.5 mr-0.5" />
                      {formatCurrency(source.revenue)}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
