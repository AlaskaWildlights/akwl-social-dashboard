export interface TikTokVideo {
  title: string;
  link?: string;
  url?: string;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  date?: string;
  posted?: string;
}

export interface GASource {
  src: string;
  sessions: number;
  revenue: number;
}

export interface WeekData {
  iso: string;
  label: string;
  ig_reach: number;
  ig_views: number;
  ig_follows: number;
  ig_visits: number;
  ig_inter: number;
  ig_clicks: number;
  ig_eng: number;
  ig_followers: number;
  fb_views: number;
  fb_visits: number;
  fb_viewers: number;
  fb_follows: number;
  fb_inter: number;
  fb_clicks: number;
  tt_views: number;
  tt_reach: number;
  tt_profile_views: number;
  tt_new_flw: number;
  tt_lost_flw: number;
  tt_net_growth: number;
  tt_likes: number;
  tt_comments: number;
  tt_shares: number;
  tt_website_clicks: number;
  tt_followers: number;
  tt_top_videos?: TikTokVideo[];
  ga_sessions: number;
  ga_eng_sessions: number;
  ga_eng_rate: number;
  ga_avg_eng_time: number;
  ga_key_events: number;
  ga_revenue: number;
  ga_sources?: GASource[];
  ga_missing?: boolean;
}

export interface Goals {
  ig_followers: number;
  ig_eng_rate: number;
  tt_followers: number;
}

export interface AgeGender {
  band: string;
  v1: number;
  v2: number;
}

export interface TopCountryCity {
  name: string;
  pct: number;
}

export interface PlatformAudience {
  age_gender: AgeGender[];
  gender_order: string[];
  top_countries: TopCountryCity[];
  top_cities: TopCountryCity[];
}

export interface TikTokDailyAudience {
  date: string;
  new_flw: number;
  total_flw: number;
  reached: number;
  engaged: number;
}

export interface AudienceData {
  ig?: PlatformAudience;
  fb?: PlatformAudience;
  tt?: {
    daily: TikTokDailyAudience[];
  };
}

export interface DashboardData {
  generated: string;
  goals: Goals;
  weeks: WeekData[];
  audience?: AudienceData;
}
